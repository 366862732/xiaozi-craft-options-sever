#version 450 compatibility  

#define VSH
#define NETHER

#include "/program/composite7.glsl"
