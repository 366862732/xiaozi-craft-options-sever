#version 330 compatibility
#extension GL_ARB_shading_language_packing : enable
#extension GL_ARB_shader_bit_encoding : enable


#include "lib/Uniforms.inc"
#include "lib/Common.inc"
#include "lib/GBuffersCommon.inc"


in vec4 texcoord;
in vec4 color;
// in vec4 lmcoord;

// in vec3 normal;
in vec4 viewPos;
in vec3 VxiuyNsNAK;

in vec2 mcLightmap;

in float materialIDs;
in float mcEntity;
in float isWater;
in float isStainedGlass;


in float invalidForVolume;
in float xMKUJsSzQw;
in float fragDepth;

in vec2 WiMNpICXBH;


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),f=ivec2(6144,6144);
 int z=v.x*v.y,i=37748736;
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int s(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int s()
 {
   return t(FloorToInt(floor(pow(float(z),.333333))));
 }
 int t()
 {
   return s(FloorToInt(floor(pow(float(i),.333333))));
 }
 int y=s();
 float m=1./y;
 int c=t();
 float F=1./c;
 vec3 d(vec2 f)
 {
   ivec2 x=ivec2(f.x*v.x,f.y*v.y);
   float z=float(x.y/y),i=float(int(x.x+mod(v.x*z,y))/y);
   i+=floor(v.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(x.x+mod(v.x*z,y),y);
   m.y=mod(x.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 r(vec3 f)
 {
   vec3 i=f.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*y,v.x);
   float z=i.x+x*y;
   r.y=i.y+floor(z/v.x)*y;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 n(vec2 v)
 {
   vec2 i=v;
   i.xy/=.75;
   int x=f.x*f.y;
   ivec2 m=ivec2(i.x*f.x,i.y*f.y);
   float z=float(m.y/c),y=float(int(m.x+mod(f.x*z,c))/c);
   y+=floor(f.x*z/c);
   vec3 r=vec3(0.,0.,y);
   r.x=mod(m.x+mod(f.x*z,c),c);
   r.y=mod(m.y,c);
   r.xyz=floor(r.xyz);
   r/=c;
   r.xyz=r.xzy;
   return r;
 }
 vec2 p(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 i=v.xzy*c;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*c,f.x);
   float z=i.x+x*c;
   r.y=i.y+floor(z/f.x)*c;
   r+=.5;
   r/=f;
   r.xy*=.75;
   return r;
 }
 const int a=384,e=a/2-64;
 int K=(a-c)/2;
 float T=floor(cameraPosition.y+.5),u=clamp(T,e-K,e-K),P=T-u;
 vec3 w(vec3 v)
 {
   return v.y+=P,v*=F,v=v+vec3(.5),v;
 }
 vec3 h(vec3 v)
 {
   return v=w(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 G(vec3 v)
 {
   return v=v-vec3(.5),v*=c,v.y-=P,v;
 }
 vec3 D(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 R(vec3 v)
 {
   return v=v-vec3(.5),v*=y,v;
 }
 vec3 D()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,y=floor(v-.0001),i=floor(x-.0001);
   return y-i;
 }
 vec3 D(vec3 v,vec3 f,vec2 i,vec2 r,vec4 m,vec4 x,inout float z,out vec2 y)
 {
   bool e=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   e=!e;
   if(x.x==8||x.x==9||x.x==79||x.x<1.||!e||x.x==20.||x.x==171.||min(abs(f.x),abs(f.z))>.2)
     z=1.;
   if(x.x==50.||x.x==48.||x.x>=44&&x.x<48||x.x==49.||x.x==52.||x.x==76.)
     {
       z=0.;
       if(f.y<.5)
         z=1.;
     }
   if(x.x==54)
     z=0.;
   if(x.x==51||x.x==53||x.x==55)
     z=0.;
   if(x.x>255)
     z=0.;
   vec3 c,s;
   if(f.x>.5)
     c=vec3(0.,0.,-1.),s=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       c=vec3(0.,0.,1.),s=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         c=vec3(1.,0.,0.),s=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           c=vec3(1.,0.,0.),s=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             c=vec3(1.,0.,0.),s=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               c=vec3(-1.,0.,0.),s=vec3(0.,-1.,0.);
   y=clamp((i.xy-r.xy)*100000.,vec2(0.),vec2(1.));
   float K=.15,u=.15;
   if(x.x==10.||x.x==11.)
     K=.1,u=.1,z=0.;
   if(x.x==51||x.x==55||x.x==53)
     K=.5,u=.1;
   if(x.x==76)
     K=.2,u=.2;
   if(x.x-255.+39.>=103.&&x.x-255.+39.<=113.)
     u=.025,K=.025;
   c=normalize(m.xyz);
   s=normalize(cross(c,f.xyz)*sign(m.w));
   vec3 n=v.xyz+mix(c*K,-c*K,vec3(y.x));
   n.xyz+=mix(s*K,-s*K,vec3(y.y));
   n.xyz-=f.xyz*u;
   return n;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO W(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 D(const vec3 v,const vec3 f,vec3 y)
 {
   vec3 x=(f+v)*.5,i=(f-v)*.5,z=y-x,r=abs(z);
   r/=i;
   vec3 K=step(r.yzx,r.xyz)*step(r.zxy,r.xyz);
   return K*sign(z);
 }
 bool D(const vec3 v,const vec3 f,Ray x,inout float z,inout vec3 y)
 {
   vec3 i=x.inv_direction*(v-1e-05-x.origin),c=x.inv_direction*(f+1e-05-x.origin),m=min(c,i),r=max(c,i);
   vec2 s=max(m.xx,m.yz);
   float K=max(s.x,s.y);
   s=min(r.xx,r.yz);
   float F=min(s.x,s.y);
   bool n=F>max(K,0.)&&max(K,0.)<z;
   if(n)
     y=D(v,f,x.origin+x.direction*K),z=K;
   return n;
 }
 float U(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 B(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),i=UnpackTwo16BitFrom32Bit(v.z),m=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=x.y;
   f.VSCbvpIaKi=i.y;
   f.vPMmNoxUfq=m.y*255.;
   f.vyHfppOAPK=pow(vec3(x.x,i.x,m.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI H(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 B(vec3 v,vec3 f)
 {
   vec3 x=D(G(v)+f+1.+D());
   float z=U(x);
   vec2 i=r(x);
   vec3 y=H(i).vyHfppOAPK;
   return y*z;
 }
 vec3 D(vec3 v,vec3 f)
 {
   vec3 x=D(G(v)+f+1.);
   float z=U(x);
   vec2 i=r(x);
   vec3 y=H(i).vyHfppOAPK;
   return y*z;
 }
 float G(float v,float f)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+f,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool B(vec3 v,float x,Ray f,bool z,inout float i,inout vec3 y)
 {
   bool r=false,t=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(x>=67.)
     return false;
   t=D(v,v+vec3(1.,1.,1.),f,i,y);
   r=t;
   #else
   if(x<40.)
     return t=D(v,v+vec3(1.,1.,1.),f,i,y),t;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float c=.5;
       if(x==41.)
         c=.9375;
       t=D(v+vec3(0.,0.,0.),v+vec3(1.,c,1.),f,i,y);
       r=r||t;
     }
   if(x==42.||x>=55.&&x<=66.)
     t=D(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,i,y),r=r||t;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float c=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         c=0.;
       t=D(v+vec3(0.,c,0.),v+vec3(.5,.5+c,.5),f,i,y);
       r=r||t;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float c=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         c=0.;
       t=D(v+vec3(.5,c,0.),v+vec3(1.,.5+c,.5),f,i,y);
       r=r||t;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float c=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         c=0.;
       t=D(v+vec3(.5,c,.5),v+vec3(1.,.5+c,1.),f,i,y);
       r=r||t;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float c=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         c=0.;
       t=D(v+vec3(0.,c,.5),v+vec3(.5,.5+c,1.),f,i,y);
       r=r||t;
     }
   if(x>=67.&&x<=82.)
     t=D(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,i,y),r=r||t;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float c=8.,s=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         c=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         s=16.;
       t=D(v+vec3(c,6.,7.)/16.,v+vec3(s,9.,9.)/16.,f,i,y);
       r=r||t;
       t=D(v+vec3(c,12.,7.)/16.,v+vec3(s,15.,9.)/16.,f,i,y);
       r=r||t;
     }
   if(x>=71.&&x<=82.)
     {
       float c=8.,s=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         s=16.;
       if(x>=75.&&x<=82.)
         c=0.;
       t=D(v+vec3(7.,6.,c)/16.,v+vec3(9.,9.,s)/16.,f,i,y);
       r=r||t;
       t=D(v+vec3(7.,12.,c)/16.,v+vec3(9.,15.,s)/16.,f,i,y);
       r=r||t;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 c=vec3(0),s=vec3(0);
       if(x==83.)
         c=vec3(0,0,0),s=vec3(16,16,3);
       if(x==84.)
         c=vec3(0,0,13),s=vec3(16,16,16);
       if(x==86.)
         c=vec3(0,0,0),s=vec3(3,16,16);
       if(x==85.)
         c=vec3(13,0,0),s=vec3(16,16,16);
       t=D(v+c/16.,v+s/16.,f,i,y);
       r=r||t;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 c=vec3(0.),s=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float K=0.;
           if(x>=91.&&x<=94.)
             K=13.;
           c=vec3(0.,K,0.)/16.;
           s=vec3(16.,K+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float K=13.;
           if(x==97.||x==98.)
             K=0.;
           c=vec3(0.,0.,K)/16.;
           s=vec3(16.,16.,K+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float K=13.;
           if(x==99.||x==100.)
             K=0.;
           c=vec3(K,0.,0.)/16.;
           s=vec3(K+3.,16.,16.)/16.;
         }
       t=D(v+c,v+s,f,i,y);
       r=r||t;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 c=vec3(0.),s=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float m=float(x)-float(103.)+1.;
           s.y=m*2./16.;
         }
       if(x==111.)
         s.y=.0625;
       if(x==112.)
         c=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(x==113.)
         c=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       t=D(v+c,v+s,f,i,y);
       r=r||t;
     }
   #endif
   #endif
   return r;
 }
 float B(vec3 v,vec3 f,int x,const int y)
 {
   Ray i=MakeRay(v,f);
   TOuWFelenO c=W(i);
   float r=1.,s=100000.;
   vec3 z=vec3(0.);
   for(int t=0;t<y;t++)
     {
       vec3 K=c.FjeDDzWIWi*F;
       vec2 m=p(K);
       vec4 n=texture2DLod(shadowcolor,m,0);
       float e=n.w*255.;
       if(abs(e-36.)<.1||abs(e-38.)<.1)
         {
           continue;
         }
       if(e<240.)
         {
           if(B(c.FjeDDzWIWi,e,i,t==0,s,z))
             {
               r=0.;
               break;
             }
         }
       b(c);
     }
   const float K=y*.33;
   r=mix(r,1.,saturate(s-K));
   return r;
 }
 vec3 g(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float c=sqrt(x.x*x.x+x.y*x.y),i=1.f-SHADOW_MAP_BIAS+c*SHADOW_MAP_BIAS;
   x.xy*=.95f/i;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 D(vec3 v,vec3 x,vec3 f,vec3 y,vec3 i,int c)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float s,z;
   vec3 r=WorldPosToShadowProjPosBias(v,y,.004,s,z),K=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z),1).x;
   K*=saturate(dot(f,y));
   K*=B(x+y*.01,f,c,3);
   {
     vec4 m=texture2DLod(shadowcolor1,r.xy-vec2(0.,.5),3);
     float t=abs(m.x*256.-(v.y+cameraPosition.y)),u=GetCausticsComposite(v,f,t),n=shadow2DLod(shadowtex0,vec3(r.xy-vec2(0.,.5),r.z+1e-06),3).x;
     K=mix(K,K*u,1.-n);
   }
   K=TintUnderwaterDepth(K);
   return K*(1.-rainStrength);
 }
 vec3 G(vec3 v,vec3 x,vec3 f,vec3 y,vec3 i,int c)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 r=G(v);
   r+=1.;
   r-=Fract01(cameraPosition+.5);
   float s,z;
   vec3 m=WorldPosToShadowProjPosBias(r+y*.99,y,.004,s,z),K=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   K*=saturate(dot(f,y));
   K*=B(x+y*.99,f,c,3);
   K=TintUnderwaterDepth(K);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 F=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   F*=F;
   K=mix(K,K*F,vec3(1.-t));
   #endif
   return K*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 x,vec3 f,vec3 y,vec3 i,int c)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float s,z;
   vec3 r=WorldPosToShadowProjPosBias(v,y,.004,s,z);
   float K=.5;
   vec3 m=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z-.0006*K),2).x;
   m*=saturate(dot(f,y));
   m*=B(x+y*.01,f,c,3);
   m=TintUnderwaterDepth(m);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(r.xy-vec2(.5,0.),r.z-.0006*K),3).x;
   vec3 F=texture2DLod(shadowcolor,vec2(r.xy-vec2(.5,0.)),3).xyz;
   F*=F;
   m=mix(m,m*F,vec3(1.-t));
   #endif
   return m*(1.-rainStrength);
 }
 vec3 V(vec2 x)
 {
   vec2 v=vec2(x.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(x.x<2./viewWidth||x.x>1.-2./viewWidth||x.y<2./viewHeight||x.y>1.-2./viewHeight)
     ;
   else
      v+=f[frameCounter/2%16]*.5;
   v=(floor(v*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,v).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 vec4 H(in sampler2D v,in vec2 x)
 {
   vec2 f=vec2(64.f,64.f);
   x*=f;
   x+=.5f;
   vec2 c=floor(x),i=fract(x);
   i.x=i.x*i.x*(3.f-2.f*i.x);
   i.y=i.y*i.y*(3.f-2.f*i.y);
   x=c+i;
   x-=.5f;
   x/=f;
   return texture2D(v,x);
 }
 float B(in float v,in float f,in float y)
 {
   if(v>f)
     return v;
   float x=2.f*y-f,c=2.f*f-3.f*y,i=v/f;
   return(x*i+c)*i*i+y;
 }
 float Q(vec3 v)
 {
   float x=.5f;
   vec2 i=v.xz/20.f;
   i.xy-=v.y/20.f;
   i.x=-i.x;
   i.x+=FRAME_TIME/40.f*x;
   i.y-=FRAME_TIME/40.f*x;
   float f=1.f,r=f,c=0.f,s=H(noisetex,i*vec2(2.f,1.2f)+vec2(0.f,i.x*2.1f)).x;
   i/=2.1f;
   i.y-=FRAME_TIME/20.f*x;
   i.x-=FRAME_TIME/30.f*x;
   c+=s*.5;
   f=2.1f;
   r+=f;
   s=H(noisetex,i*vec2(2.f,1.4f)+vec2(0.f,-i.x*2.1f)).x;
   i/=1.5f;
   i.x+=FRAME_TIME/20.f*x;
   s*=f;
   c+=s;
   f=17.25f;
   r+=f;
   s=H(noisetex,i*vec2(1.f,.75f)+vec2(0.f,i.x*1.1f)).x;
   i/=1.5f;
   i.x-=FRAME_TIME/55.f*x;
   s*=f;
   c+=s;
   f=15.25f;
   r+=f;
   s=H(noisetex,i*vec2(1.f,.75f)+vec2(0.f,-i.x*1.7f)).x;
   i/=1.9f;
   i.x+=FRAME_TIME/155.f*x;
   s*=f;
   c+=s;
   f=29.25f;
   r+=f;
   s=abs(H(noisetex,i*vec2(1.f,.8f)+vec2(0.f,-i.x*1.7f)).x*2.f-1.f);
   i/=2.f;
   i.x+=FRAME_TIME/155.f*x;
   s=1.f-B(s,.2f,.1f);
   s*=f;
   c+=s;
   f=15.25f;
   r+=f;
   s=abs(H(noisetex,i*vec2(1.f,.8f)+vec2(0.f,i.x*1.7f)).x*2.f-1.f);
   s=1.f-B(s,.2f,.1f);
   s*=f;
   c+=s;
   c/=r;
   return c;
 }
 void main()
 {
   vec4 x=texture2D(texture,texcoord.xy,0);
   vec3 v=x.xyz*color.xyz;
   float i=1.;
   if(xMKUJsSzQw<.5)
     {
       i=min(x.w*7.,1.);
       vec3 f=(shadowModelViewInverse*vec4(viewPos.xyz,1.)).xyz;
       f+=cameraPosition.xyz;
       gl_FragData[0]=vec4(v.xyz,i);
       gl_FragData[1]=vec4(f.y/256.,1.-isWater,0.,i);
     }
   else
     {
       if(invalidForVolume>.0001)
         {
           discard;
         }
       v=pow(v,vec3(2.2));
       if(abs(mcEntity-50.)<.1)
         v.xyz=KelvinToRGB(float(TORCHLIGHT_COLOR_TEMPERATURE))*.4;
       if(abs(mcEntity-76.)<.1)
         v.xyz=vec3(1.,.02,.01)*.05;
       if(abs(mcEntity-51.)<.1)
         v.xyz=vec3(1.,.175,.0125);
       if(abs(mcEntity-55.)<.1)
         v.xyz=GetGlowBerryColor(VxiuyNsNAK);
       if(mcEntity>=43.9&&mcEntity<47.9)
         {
           float f=mcEntity-43.;
           vec3 r=pow(v.xyz,vec3(2.));
           r=max(vec3(0.),r);
           v.xyz=(r+.05)*KelvinToRGB(CANDLELIGHT_COLOR_TEMPERATURE)*.25*f;
         }
       if(abs(mcEntity-47.)<.1)
         ;
       if(abs(mcEntity-54.)<.1)
         v.xyz=vec3(.007,.0044,.0012);
       if(abs(mcEntity-48.)<.1)
         v.xyz=vec3(.04,.045,.05);
       if(abs(mcEntity-52.5)<1.5)
         v.xyz=vec3(0.,.9,1.);
       float y=clamp((abs(color.x-color.y)+abs(color.x-color.z)+abs(color.y-color.z))*500.,0.,1.),c=mix(1.,saturate(dot(x.xyz,vec3(.333333)))*.996078,y);
       gl_FragData[0]=vec4(v.xyz,(materialIDs+.1)/255.*i);
       gl_FragData[1]=vec4(WiMNpICXBH.xy,mcLightmap.y,c);
     }
 };



