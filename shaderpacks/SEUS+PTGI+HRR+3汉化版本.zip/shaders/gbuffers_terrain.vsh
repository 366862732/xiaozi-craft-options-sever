#version 330 compatibility



#define GLOWING_REDSTONE_BLOCK // If enabled, redstone blocks are treated as light sources for GI
#define GLOWING_LAPIS_LAZULI_BLOCK // If enabled, lapis lazuli blocks are treated as light sources for GI


#define GENERAL_GRASS_FIX

#include "lib/Uniforms.inc"
#include "lib/Common.inc"


attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;



out vec4 color;
out vec4 texcoord;
out vec4 lmcoord;
out vec3 worldPosition;
out vec3 viewPos;
out vec4 preDownscaleProjPos;
out vec4 glPosition;

out vec3 worldNormal;

out vec2 blockLight;

out float materialIDs;

out mat3 tbnMatrix;
out vec3 tangent;
out vec3 binormal;
out vec3 normal;


#include "lib/Materials.inc"

 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),s=ivec2(6144,6144);
 int z=v.x*v.y,y=37748736;
 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   return f(FloorToInt(floor(pow(float(z),.333333))));
 }
 int t()
 {
   return t(FloorToInt(floor(pow(float(y),.333333))));
 }
 int n=f();
 float m=1./n;
 int i=t();
 float M=1./i;
 vec3 d(vec2 y)
 {
   ivec2 x=ivec2(y.x*v.x,y.y*v.y);
   float s=float(x.y/n),i=float(int(x.x+mod(v.x*s,n))/n);
   i+=floor(v.x*s/n);
   vec3 f=vec3(0.,0.,i);
   f.x=mod(x.x+mod(v.x*s,n),n);
   f.y=mod(x.y,n);
   f.xyz=floor(f.xyz);
   f/=n;
   f.xyz=f.xzy;
   return f;
 }
 vec2 e(vec3 y)
 {
   vec3 i=y.xzy*n;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*n,v.x);
   float s=i.x+x*n;
   f.y=i.y+floor(s/v.x)*n;
   f+=.5;
   f/=v;
   return f;
 }
 vec3 r(vec2 v)
 {
   vec2 x=v;
   x.xy/=.75;
   int f=s.x*s.y;
   ivec2 y=ivec2(x.x*s.x,x.y*s.y);
   float z=float(y.y/i),n=float(int(y.x+mod(s.x*z,i))/i);
   n+=floor(s.x*z/i);
   vec3 m=vec3(0.,0.,n);
   m.x=mod(y.x+mod(s.x*z,i),i);
   m.y=mod(y.y,i);
   m.xyz=floor(m.xyz);
   m/=i;
   m.xyz=m.xzy;
   return m;
 }
 vec2 p(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 f=v.xzy*i;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 y;
   y.x=mod(f.x+x*i,s.x);
   float m=f.x+x*i;
   y.y=f.y+floor(m/s.x)*i;
   y+=.5;
   y/=s;
   y.xy*=.75;
   return y;
 }
 const int g=384,b=g/2-64;
 int l=(g-i)/2;
 float c=floor(cameraPosition.y+.5),E=clamp(c,b-l,b-l),a=c-E;
 vec3 G(vec3 v)
 {
   return v.y+=a,v*=M,v=v+vec3(.5),v;
 }
 vec3 w(vec3 v)
 {
   return v=G(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 F(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v.y-=a,v;
 }
 vec3 T(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 h(vec3 v)
 {
   return v=v-vec3(.5),v*=n,v;
 }
 vec3 F()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,i=floor(v-.0001),s=floor(x-.0001);
   return i-s;
 }
 vec3 F(vec3 v,vec3 y,vec2 f,vec2 x,vec4 m,vec4 i,inout float s,out vec2 l)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!r||i.x==20.||i.x==171.||min(abs(y.x),abs(y.z))>.2)
     s=1.;
   if(i.x==50.||i.x==48.||i.x>=44&&i.x<48||i.x==49.||i.x==52.||i.x==76.)
     {
       s=0.;
       if(y.y<.5)
         s=1.;
     }
   if(i.x==54)
     s=0.;
   if(i.x==51||i.x==53||i.x==55)
     s=0.;
   if(i.x>255)
     s=0.;
   vec3 g,n;
   if(y.x>.5)
     g=vec3(0.,0.,-1.),n=vec3(0.,-1.,0.);
   else
      if(y.x<-.5)
       g=vec3(0.,0.,1.),n=vec3(0.,-1.,0.);
     else
        if(y.y>.5)
         g=vec3(1.,0.,0.),n=vec3(0.,0.,1.);
       else
          if(y.y<-.5)
           g=vec3(1.,0.,0.),n=vec3(0.,0.,-1.);
         else
            if(y.z>.5)
             g=vec3(1.,0.,0.),n=vec3(0.,-1.,0.);
           else
              if(y.z<-.5)
               g=vec3(-1.,0.,0.),n=vec3(0.,-1.,0.);
   l=clamp((f.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float z=.15,t=.15;
   if(i.x==10.||i.x==11.)
     z=.1,t=.1,s=0.;
   if(i.x==51||i.x==55||i.x==53)
     z=.5,t=.1;
   if(i.x==76)
     z=.2,t=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     t=.025,z=.025;
   g=normalize(m.xyz);
   n=normalize(cross(g,y.xyz)*sign(m.w));
   vec3 e=v.xyz+mix(g*z,-g*z,vec3(l.x));
   e.xyz+=mix(n*z,-n*z,vec3(l.y));
   e.xyz-=y.xyz*t;
   return e;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO P(Ray v)
 {
   TOuWFelenO i;
   i.FjeDDzWIWi=floor(v.origin);
   i.FjeDDzWIWiOrigin=i.FjeDDzWIWi;
   i.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.ihCMMEIfgL=sign(v.direction);
   i.HHiebGwFJJ=(sign(v.direction)*(i.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*i.gjulCSuvVu;
   i.GTJIHvOSbK=vec3(0.);
   return i;
 }
 void R(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 F(const vec3 v,const vec3 y,vec3 f)
 {
   vec3 x=(y+v)*.5,s=(y-v)*.5,i=f-x,m=abs(i);
   m/=s;
   vec3 z=step(m.yzx,m.xyz)*step(m.zxy,m.xyz);
   return z*sign(i);
 }
 bool F(const vec3 v,const vec3 i,Ray y,inout float x,inout vec3 z)
 {
   vec3 n=y.inv_direction*(v-1e-05-y.origin),s=y.inv_direction*(i+1e-05-y.origin),m=min(s,n),l=max(s,n);
   vec2 f=max(m.xx,m.yz);
   float g=max(f.x,f.y);
   f=min(l.xx,l.yz);
   float M=min(f.x,f.y);
   bool t=M>max(g,0.)&&max(g,0.)<x;
   if(t)
     z=F(v,i,y.origin+y.direction*g),x=g;
   return t;
 }
 float W(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 D(eAMCZAKEcI v)
 {
   vec4 i;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   i.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   i.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   i.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return i;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI i;
   vec2 y=UnpackTwo16BitFrom32Bit(v.y),x=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   i.nrlJXyapkV=v.x;
   i.QQevGhUGeB=y.y;
   i.VSCbvpIaKi=x.y;
   i.vPMmNoxUfq=s.y*255.;
   i.vyHfppOAPK=pow(vec3(y.x,x.x,s.x),vec3(8.));
   return i;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 i)
 {
   vec3 x=T(F(v)+i+1.+F());
   float s=W(x);
   vec2 y=e(x);
   vec3 z=U(y).vyHfppOAPK;
   return z*s;
 }
 vec3 F(vec3 v,vec3 i)
 {
   vec3 x=T(F(v)+i+1.);
   float s=W(x);
   vec2 y=e(x);
   vec3 z=U(y).vyHfppOAPK;
   return z*s;
 }
 float G(float v,float i)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+i,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray i,bool y,inout float f,inout vec3 n)
 {
   bool s=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=67.)
     return false;
   m=F(v,v+vec3(1.,1.,1.),i,f,n);
   s=m;
   #else
   if(x<40.)
     return m=F(v,v+vec3(1.,1.,1.),i,f,n),m;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float z=.5;
       if(x==41.)
         z=.9375;
       m=F(v+vec3(0.,0.,0.),v+vec3(1.,z,1.),i,f,n);
       s=s||m;
     }
   if(x==42.||x>=55.&&x<=66.)
     m=F(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,n),s=s||m;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         z=0.;
       m=F(v+vec3(0.,z,0.),v+vec3(.5,.5+z,.5),i,f,n);
       s=s||m;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float z=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         z=0.;
       m=F(v+vec3(.5,z,0.),v+vec3(1.,.5+z,.5),i,f,n);
       s=s||m;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float z=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         z=0.;
       m=F(v+vec3(.5,z,.5),v+vec3(1.,.5+z,1.),i,f,n);
       s=s||m;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float z=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         z=0.;
       m=F(v+vec3(0.,z,.5),v+vec3(.5,.5+z,1.),i,f,n);
       s=s||m;
     }
   if(x>=67.&&x<=82.)
     m=F(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,n),s=s||m;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float z=8.,g=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         z=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         g=16.;
       m=F(v+vec3(z,6.,7.)/16.,v+vec3(g,9.,9.)/16.,i,f,n);
       s=s||m;
       m=F(v+vec3(z,12.,7.)/16.,v+vec3(g,15.,9.)/16.,i,f,n);
       s=s||m;
     }
   if(x>=71.&&x<=82.)
     {
       float z=8.,t=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         t=16.;
       if(x>=75.&&x<=82.)
         z=0.;
       m=F(v+vec3(7.,6.,z)/16.,v+vec3(9.,9.,t)/16.,i,f,n);
       s=s||m;
       m=F(v+vec3(7.,12.,z)/16.,v+vec3(9.,15.,t)/16.,i,f,n);
       s=s||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 z=vec3(0),t=vec3(0);
       if(x==83.)
         z=vec3(0,0,0),t=vec3(16,16,3);
       if(x==84.)
         z=vec3(0,0,13),t=vec3(16,16,16);
       if(x==86.)
         z=vec3(0,0,0),t=vec3(3,16,16);
       if(x==85.)
         z=vec3(13,0,0),t=vec3(16,16,16);
       m=F(v+z/16.,v+t/16.,i,f,n);
       s=s||m;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 z=vec3(0.),t=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float g=0.;
           if(x>=91.&&x<=94.)
             g=13.;
           z=vec3(0.,g,0.)/16.;
           t=vec3(16.,g+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float g=13.;
           if(x==97.||x==98.)
             g=0.;
           z=vec3(0.,0.,g)/16.;
           t=vec3(16.,16.,g+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float g=13.;
           if(x==99.||x==100.)
             g=0.;
           z=vec3(g,0.,0.)/16.;
           t=vec3(g+3.,16.,16.)/16.;
         }
       m=F(v+z,v+t,i,f,n);
       s=s||m;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 z=vec3(0.),t=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float g=float(x)-float(103.)+1.;
           t.y=g*2./16.;
         }
       if(x==111.)
         t.y=.0625;
       if(x==112.)
         z=vec3(1.,0.,1.)/16.,t=vec3(15.,1.,15.)/16.;
       if(x==113.)
         z=vec3(1.,0.,1.)/16.,t=vec3(15.,.5,15.)/16.;
       m=F(v+z,v+t,i,f,n);
       s=s||m;
     }
   #endif
   #endif
   return s;
 }
 float D(vec3 v,vec3 i,int z,const int x)
 {
   Ray s=MakeRay(v,i);
   TOuWFelenO y=P(s);
   float f=1.,g=100000.;
   vec3 n=vec3(0.);
   for(int m=0;m<x;m++)
     {
       vec3 t=y.FjeDDzWIWi*M;
       vec2 l=p(t);
       vec4 r=texture2DLod(shadowcolor,l,0);
       float c=r.w*255.;
       if(abs(c-36.)<.1||abs(c-38.)<.1)
         {
           continue;
         }
       if(c<240.)
         {
           if(D(y.FjeDDzWIWi,c,s,m==0,g,n))
             {
               f=0.;
               break;
             }
         }
       R(y);
     }
   const float t=x*.33;
   f=mix(f,1.,saturate(g-t));
   return f;
 }
 vec3 A(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float z=sqrt(x.x*x.x+x.y*x.y),s=1.f-SHADOW_MAP_BIAS+z*SHADOW_MAP_BIAS;
   x.xy*=.95f/s;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 A(vec3 v,vec3 x,vec3 i,vec3 z,vec3 f,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float y,t;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,y,t),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z),1).x;
   m*=saturate(dot(i,z));
   m*=D(x+z*.01,i,n,3);
   {
     vec4 g=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),3);
     float l=abs(g.x*256.-(v.y+cameraPosition.y)),b=GetCausticsComposite(v,i,l),c=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),3).x;
     m=mix(m,m*b,1.-c);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 F(vec3 v,vec3 x,vec3 i,vec3 z,vec3 f,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 s=F(v);
   s+=1.;
   s-=Fract01(cameraPosition+.5);
   float y,t;
   vec3 m=WorldPosToShadowProjPosBias(s+z*.99,z,.004,y,t),g=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   g*=saturate(dot(i,z));
   g*=D(x+z*.99,i,n,3);
   g=TintUnderwaterDepth(g);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float l=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   g=mix(g,g*r,vec3(1.-l));
   #endif
   return g*(1.-rainStrength);
 }
 vec3 G(vec3 v,vec3 x,vec3 i,vec3 z,vec3 f,int n)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float y,t;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,y,t);
   float g=.5;
   vec3 m=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*g),2).x;
   m*=saturate(dot(i,z));
   m*=D(x+z*.01,i,n,3);
   m=TintUnderwaterDepth(m);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float l=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*g),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   m=mix(m,m*r,vec3(1.-l));
   #endif
   return m*(1.-rainStrength);
 }
 vec3 H(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight));
   x*=1./64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      x+=f[frameCounter/2%16]*.5;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 void main()
 {
   color=gl_Color;
   texcoord=gl_MultiTexCoord0;
   lmcoord=gl_TextureMatrix[1]*gl_MultiTexCoord1;
   blockLight.x=clamp(lmcoord.x*33.05f/32.f-.0328125f,0.f,1.f);
   blockLight.y=clamp(lmcoord.y*33.75f/32.f-.0328125f,0.f,1.f);
   worldNormal=gl_Normal;
   vec4 x=gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex;
   worldPosition=x.xyz+cameraPosition.xyz;
   viewPos=(gl_ModelViewMatrix*gl_Vertex).xyz;
   materialIDs=MAT_ID_OPAQUE;
   float v=0.f,s=abs(normalize(gl_Normal.xz).x),z=abs(gl_Normal.y);
   if(mc_Entity.x==31.||mc_Entity.x==38.f||mc_Entity.x==37.f||mc_Entity.x==1925.f||mc_Entity.x==1920.f||mc_Entity.x==1921.f||mc_Entity.x==2.&&gl_Normal.y<.5&&s>.01&&s<.99&&z<.9)
     materialIDs=MAT_ID_GRASS,v=1.f;
   #ifdef GENERAL_GRASS_FIX
   if(abs(worldNormal.x)>.01&&abs(worldNormal.x)<.99||abs(worldNormal.y)>.01&&abs(worldNormal.y)<.99||abs(worldNormal.z)>.01&&abs(worldNormal.z)<.99)
     materialIDs=MAT_ID_GRASS;
   #endif
   if(mc_Entity.x==175.f)
     materialIDs=MAT_ID_GRASS;
   if(mc_Entity.x==59.)
     materialIDs=MAT_ID_GRASS,v=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     {
       if(color.x>.999&&color.y>.999&&color.z>.999)
         ;
       else
          materialIDs=MAT_ID_LEAVES;
       if(abs(color.x-color.y)>.001||abs(color.x-color.z)>.001||abs(color.y-color.z)>.001)
         materialIDs=MAT_ID_LEAVES;
     }
   if(mc_Entity.x==50||mc_Entity.x==52)
     materialIDs=MAT_ID_TORCH;
   if(mc_Entity.x>=44&&mc_Entity.x<=48)
     materialIDs=MAT_ID_CANDLE;
   if(mc_Entity.x==49)
     materialIDs=MAT_ID_END_ROD;
   if(mc_Entity.x==54)
     materialIDs=MAT_ID_GLOW_LICHEN;
   if(mc_Entity.x==48)
     materialIDs=MAT_ID_SEA_PICKLE;
   if(mc_Entity.x==10||mc_Entity.x==11)
     materialIDs=MAT_ID_LAVA;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==169||mc_Entity.x==91)
     materialIDs=MAT_ID_GLOWSTONE;
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     materialIDs=MAT_ID_GLOWSTONE;
   #endif
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     materialIDs=MAT_ID_GLOWSTONE;
   #endif
   #ifdef GLOWING_EMERALD_BLOCK
   if(mc_Entity.x==133)
     materialIDs=MAT_ID_GLOWSTONE;
   #endif
   if(mc_Entity.x==51||mc_Entity.x==53)
     materialIDs=MAT_ID_FIRE;
   if(mc_Entity.x==55)
     materialIDs=MAT_ID_GLOW_BERRIES;
   if(mc_Entity.x==188||mc_Entity.x==189||mc_Entity.x==190||mc_Entity.x==191)
     materialIDs=MAT_ID_LIT_FURNACE;
   float m=1.;
   if(color.x==1.&&color.y==1.&&color.z==1.)
     m=0.;
   normal=normalize(gl_NormalMatrix*gl_Normal);
   float i=-1.;
   if(gl_Normal.x>.5)
     tangent=normalize(gl_NormalMatrix*vec3(0.,0.,i)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
   else
      if(gl_Normal.x<-.5)
       tangent=normalize(gl_NormalMatrix*vec3(0.,0.,1.)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
     else
        if(gl_Normal.y>.5)
         tangent=normalize(gl_NormalMatrix*vec3(1.,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,0.,1.));
       else
          if(gl_Normal.y<-.5)
           tangent=normalize(gl_NormalMatrix*vec3(1.,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,0.,-1.));
         else
            if(gl_Normal.z>.5)
             tangent=normalize(gl_NormalMatrix*vec3(1.,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
           else
              if(gl_Normal.z<-.5)
               tangent=normalize(gl_NormalMatrix*vec3(i,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
   tbnMatrix=mat3(tangent.x,binormal.x,normal.x,tangent.y,binormal.y,normal.y,tangent.z,binormal.z,normal.z);
   gl_Position=gl_ProjectionMatrix*gbufferModelView*x;
   FinalVertexTransformTAA(gl_Position,preDownscaleProjPos);
   glPosition=gl_Position;
 };



