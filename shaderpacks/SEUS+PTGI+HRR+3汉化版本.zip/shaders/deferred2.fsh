#version 330 compatibility



/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//#define HALF_RES_TRACE

/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Do not change the name of these variables or their type. The Shaders Mod reads these lines and determines values to send to the inner-workings
//of the shaders mod. The shaders mod only reads these lines and doesn't actually know the real value assigned to these variables in GLSL.
//Some of these variables are critical for proper operation. Change at your own risk.

//END OF INTERNAL VARIABLES//




in vec4 texcoord;

in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSkyUp;
in vec3 colorTorchlight;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;


in vec3 worldLightVector;
in vec3 worldSunVector;


in mat4 gbufferPreviousModelViewInverse;
in mat4 gbufferPreviousProjectionInverse;


#include "lib/Uniforms.inc"
#include "lib/Common.inc"

#include "lib/Materials.inc"


/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






// vec4 GetViewPosition(in vec2 coord, in float depth) 
// {	
// 	vec2 tcoord = coord;
// 	TemporalJitterProjPosInv01(tcoord);

// 	vec4 fragposition = gbufferProjectionInverse * vec4(tcoord.s * 2.0f - 1.0f, tcoord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
// 		 fragposition /= fragposition.w;

	
// 	return fragposition;
// }













#include "lib/GBufferData.inc"
 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),s=ivec2(6144,6144);
 int y=v.x*v.y,z=37748736;
 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return f(FloorToInt(floor(pow(float(y),.333333))));
 }
 int f()
 {
   return d(FloorToInt(floor(pow(float(z),.333333))));
 }
 int m=d();
 float t=1./m;
 int i=f();
 float n=1./i;
 vec3 e(vec2 s)
 {
   ivec2 x=ivec2(s.x*v.x,s.y*v.y);
   float z=float(x.y/m),i=float(int(x.x+mod(v.x*z,m))/m);
   i+=floor(v.x*z/m);
   vec3 f=vec3(0.,0.,i);
   f.x=mod(x.x+mod(v.x*z,m),m);
   f.y=mod(x.y,m);
   f.xyz=floor(f.xyz);
   f/=m;
   f.xyz=f.xzy;
   return f;
 }
 vec2 r(vec3 f)
 {
   vec3 i=f.xzy*m;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*m,v.x);
   float s=i.x+x*m;
   r.y=i.y+floor(s/v.x)*m;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 p(vec2 v)
 {
   vec2 f=v;
   f.xy/=.75;
   int x=s.x*s.y;
   ivec2 d=ivec2(f.x*s.x,f.y*s.y);
   float z=float(d.y/i),y=float(int(d.x+mod(s.x*z,i))/i);
   y+=floor(s.x*z/i);
   vec3 m=vec3(0.,0.,y);
   m.x=mod(d.x+mod(s.x*z,i),i);
   m.y=mod(d.y,i);
   m.xyz=floor(m.xyz);
   m/=i;
   m.xyz=m.xzy;
   return m;
 }
 vec2 g(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 f=v.xzy*i;
   f=floor(f+1e-05);
   float x=f.z;
   vec2 r;
   r.x=mod(f.x+x*i,s.x);
   float z=f.x+x*i;
   r.y=f.y+floor(z/s.x)*i;
   r+=.5;
   r/=s;
   r.xy*=.75;
   return r;
 }
 const int c=384,w=c/2-64;
 int h=(c-i)/2;
 float a=floor(cameraPosition.y+.5),K=clamp(a,w-h,w-h),l=a-K;
 vec3 D(vec3 v)
 {
   return v.y+=l,v*=n,v=v+vec3(.5),v;
 }
 vec3 F(vec3 v)
 {
   return v=D(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 G(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v.y-=l,v;
 }
 vec3 T(vec3 v)
 {
   return v*=t,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 S(vec3 v)
 {
   return v=v-vec3(.5),v*=m,v;
 }
 vec3 D()
 {
   vec3 v=cameraPosition.xyz+.5,s=previousCameraPosition.xyz+.5,x=floor(v-.0001),i=floor(s-.0001);
   return x-i;
 }
 vec3 D(vec3 v,vec3 f,vec2 s,vec2 x,vec4 d,vec4 i,inout float z,out vec2 y)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!r||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     z=1.;
   if(i.x==50.||i.x==48.||i.x>=44&&i.x<48||i.x==49.||i.x==52.||i.x==76.)
     {
       z=0.;
       if(f.y<.5)
         z=1.;
     }
   if(i.x==54)
     z=0.;
   if(i.x==51||i.x==53||i.x==55)
     z=0.;
   if(i.x>255)
     z=0.;
   vec3 t,m;
   if(f.x>.5)
     t=vec3(0.,0.,-1.),m=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       t=vec3(0.,0.,1.),m=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         t=vec3(1.,0.,0.),m=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           t=vec3(1.,0.,0.),m=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             t=vec3(1.,0.,0.),m=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               t=vec3(-1.,0.,0.),m=vec3(0.,-1.,0.);
   y=clamp((s.xy-x.xy)*100000.,vec2(0.),vec2(1.));
   float n=.15,w=.15;
   if(i.x==10.||i.x==11.)
     n=.1,w=.1,z=0.;
   if(i.x==51||i.x==55||i.x==53)
     n=.5,w=.1;
   if(i.x==76)
     n=.2,w=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     w=.025,n=.025;
   t=normalize(d.xyz);
   m=normalize(cross(t,f.xyz)*sign(d.w));
   vec3 K=v.xyz+mix(t*n,-t*n,vec3(y.x));
   K.xyz+=mix(m*n,-m*n,vec3(y.y));
   K.xyz-=f.xyz*w;
   return K;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO P(Ray v)
 {
   TOuWFelenO f;
   f.FjeDDzWIWi=floor(v.origin);
   f.FjeDDzWIWiOrigin=f.FjeDDzWIWi;
   f.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   f.ihCMMEIfgL=sign(v.direction);
   f.HHiebGwFJJ=(sign(v.direction)*(f.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*f.gjulCSuvVu;
   f.GTJIHvOSbK=vec3(0.);
   return f;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 D(const vec3 v,const vec3 f,vec3 m)
 {
   vec3 x=(f+v)*.5,t=(f-v)*.5,i=m-x,s=abs(i);
   s/=t;
   vec3 z=step(s.yzx,s.xyz)*step(s.zxy,s.xyz);
   return z*sign(i);
 }
 bool D(const vec3 v,const vec3 f,Ray m,inout float x,inout vec3 z)
 {
   vec3 y=m.inv_direction*(v-1e-05-m.origin),i=m.inv_direction*(f+1e-05-m.origin),s=min(i,y),d=max(i,y);
   vec2 r=max(s.xx,s.yz);
   float t=max(r.x,r.y);
   r=min(d.xx,d.yz);
   float n=min(r.x,r.y);
   bool w=n>max(t,0.)&&max(t,0.)<x;
   if(w)
     z=D(v,f,m.origin+m.direction*t),x=t;
   return w;
 }
 float W(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 o(eAMCZAKEcI v)
 {
   vec4 f;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   f.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   f.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   f.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   f.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return f;
 }
 eAMCZAKEcI R(vec4 v)
 {
   eAMCZAKEcI f;
   vec2 i=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),s=UnpackTwo16BitFrom32Bit(v.w);
   f.nrlJXyapkV=v.x;
   f.QQevGhUGeB=i.y;
   f.VSCbvpIaKi=m.y;
   f.vPMmNoxUfq=s.y*255.;
   f.vyHfppOAPK=pow(vec3(i.x,m.x,s.x),vec3(8.));
   return f;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,R(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec3 f=T(G(v)+y+1.+D());
   float x=W(f);
   vec2 i=r(f);
   vec3 z=U(i).vyHfppOAPK;
   return z*x;
 }
 vec3 F(vec3 v,vec3 y)
 {
   vec3 f=T(G(v)+y+1.);
   float x=W(f);
   vec2 i=r(f);
   vec3 z=U(i).vyHfppOAPK;
   return z*x;
 }
 float G(float v,float z)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+z,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray z,bool f,inout float i,inout vec3 y)
 {
   bool m=false,t=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=67.)
     return false;
   t=D(v,v+vec3(1.,1.,1.),z,i,y);
   m=t;
   #else
   if(x<40.)
     return t=D(v,v+vec3(1.,1.,1.),z,i,y),t;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float r=.5;
       if(x==41.)
         r=.9375;
       t=D(v+vec3(0.,0.,0.),v+vec3(1.,r,1.),z,i,y);
       m=m||t;
     }
   if(x==42.||x>=55.&&x<=66.)
     t=D(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),z,i,y),m=m||t;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         r=0.;
       t=D(v+vec3(0.,r,0.),v+vec3(.5,.5+r,.5),z,i,y);
       m=m||t;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float r=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         r=0.;
       t=D(v+vec3(.5,r,0.),v+vec3(1.,.5+r,.5),z,i,y);
       m=m||t;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float r=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         r=0.;
       t=D(v+vec3(.5,r,.5),v+vec3(1.,.5+r,1.),z,i,y);
       m=m||t;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float r=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         r=0.;
       t=D(v+vec3(0.,r,.5),v+vec3(.5,.5+r,1.),z,i,y);
       m=m||t;
     }
   if(x>=67.&&x<=82.)
     t=D(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,z,i,y),m=m||t;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float r=8.,s=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         r=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         s=16.;
       t=D(v+vec3(r,6.,7.)/16.,v+vec3(s,9.,9.)/16.,z,i,y);
       m=m||t;
       t=D(v+vec3(r,12.,7.)/16.,v+vec3(s,15.,9.)/16.,z,i,y);
       m=m||t;
     }
   if(x>=71.&&x<=82.)
     {
       float r=8.,w=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         w=16.;
       if(x>=75.&&x<=82.)
         r=0.;
       t=D(v+vec3(7.,6.,r)/16.,v+vec3(9.,9.,w)/16.,z,i,y);
       m=m||t;
       t=D(v+vec3(7.,12.,r)/16.,v+vec3(9.,15.,w)/16.,z,i,y);
       m=m||t;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 r=vec3(0),s=vec3(0);
       if(x==83.)
         r=vec3(0,0,0),s=vec3(16,16,3);
       if(x==84.)
         r=vec3(0,0,13),s=vec3(16,16,16);
       if(x==86.)
         r=vec3(0,0,0),s=vec3(3,16,16);
       if(x==85.)
         r=vec3(13,0,0),s=vec3(16,16,16);
       t=D(v+r/16.,v+s/16.,z,i,y);
       m=m||t;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 r=vec3(0.),s=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float n=0.;
           if(x>=91.&&x<=94.)
             n=13.;
           r=vec3(0.,n,0.)/16.;
           s=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float w=13.;
           if(x==97.||x==98.)
             w=0.;
           r=vec3(0.,0.,w)/16.;
           s=vec3(16.,16.,w+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float n=13.;
           if(x==99.||x==100.)
             n=0.;
           r=vec3(n,0.,0.)/16.;
           s=vec3(n+3.,16.,16.)/16.;
         }
       t=D(v+r,v+s,z,i,y);
       m=m||t;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 r=vec3(0.),s=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float n=float(x)-float(103.)+1.;
           s.y=n*2./16.;
         }
       if(x==111.)
         s.y=.0625;
       if(x==112.)
         r=vec3(1.,0.,1.)/16.,s=vec3(15.,1.,15.)/16.;
       if(x==113.)
         r=vec3(1.,0.,1.)/16.,s=vec3(15.,.5,15.)/16.;
       t=D(v+r,v+s,z,i,y);
       m=m||t;
     }
   #endif
   #endif
   return m;
 }
 float D(vec3 v,vec3 z,int r,const int m)
 {
   Ray x=MakeRay(v,z);
   TOuWFelenO f=P(x);
   float i=1.,s=100000.;
   vec3 y=vec3(0.);
   for(int t=0;t<m;t++)
     {
       vec3 w=f.FjeDDzWIWi*n;
       vec2 K=g(w);
       vec4 d=texture2DLod(shadowcolor,K,0);
       float c=d.w*255.;
       if(abs(c-36.)<.1||abs(c-38.)<.1)
         {
           continue;
         }
       if(c<240.)
         {
           if(D(f.FjeDDzWIWi,c,x,t==0,s,y))
             {
               i=0.;
               break;
             }
         }
       b(f);
     }
   const float t=m*.33;
   i=mix(i,1.,saturate(s-t));
   return i;
 }
 vec3 L(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float r=sqrt(x.x*x.x+x.y*x.y),i=1.f-SHADOW_MAP_BIAS+r*SHADOW_MAP_BIAS;
   x.xy*=.95f/i;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 F(vec3 v,vec3 x,vec3 i,vec3 z,vec3 r,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float f,t;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,f,t),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z),1).x;
   m*=saturate(dot(i,z));
   m*=D(x+z*.01,i,y,3);
   {
     vec4 d=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),3);
     float w=abs(d.x*256.-(v.y+cameraPosition.y)),n=GetCausticsComposite(v,i,w),K=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),3).x;
     m=mix(m,m*n,1.-K);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 G(vec3 v,vec3 x,vec3 i,vec3 z,vec3 r,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=G(v);
   f+=1.;
   f-=Fract01(cameraPosition+.5);
   float s,t;
   vec3 m=WorldPosToShadowProjPosBias(f+z*.99,z,.004,s,t),w=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   w*=saturate(dot(i,z));
   w*=D(x+z*.99,i,y,3);
   w=TintUnderwaterDepth(w);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 K=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   K*=K;
   w=mix(w,w*K,vec3(1.-n));
   #endif
   return w*(1.-rainStrength);
 }
 vec3 L(vec3 v,vec3 x,vec3 i,vec3 z,vec3 r,int y)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float f,t;
   vec3 s=WorldPosToShadowProjPosBias(v,z,.004,f,t);
   float m=.5;
   vec3 w=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*m),2).x;
   w*=saturate(dot(i,z));
   w*=D(x+z*.01,i,y,3);
   w=TintUnderwaterDepth(w);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float n=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*m),3).x;
   vec3 K=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   K*=K;
   w=mix(w,w*K,vec3(1.-n));
   #endif
   return w*(1.-rainStrength);
 }
 vec3 H(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight));
   x*=1./64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      x+=m[frameCounter/2%16]*.5;
   x=(floor(x*64.)+.5)/64.;
   vec3 f=texture2D(noisetex,x).xyz,i=vec3(sqrt(.2),sqrt(2.),1.61803);
   f=mod(f+float(frameCounter%2)*.5,vec3(1.));
   return f;
 }
 vec2 F(vec2 v,float z,out float x)
 {
   vec2 r=1./vec2(viewWidth,viewHeight);
   vec4 f;
   f.x=texture2D(depthtex1,v+r*vec2(1.,1.)).x;
   f.y=texture2D(depthtex1,v+r*vec2(1.,-1.)).x;
   f.z=texture2D(depthtex1,v+r*vec2(-1.,1.)).x;
   f.w=texture2D(depthtex1,v+r*vec2(-1.,-1.)).x;
   vec2 t=vec2(0.,0.);
   if(f.x<z)
     t=vec2(1.,1.);
   if(f.y<z)
     t=vec2(1.,-1.);
   if(f.z<z)
     t=vec2(-1.,1.);
   if(f.w<z)
     t=vec2(-1.,-1.);
   x=min(min(min(f.x,f.y),f.z),f.w);
   return v+r*t;
 }
 vec3 H(vec3 v,vec2 x)
 {
   x=x*.99+.005;
   float f=6.28319*x.x,s=sqrt(x.y);
   vec3 m=normalize(cross(v,vec3(0.,1.,1.))),z=cross(v,m),i=m*cos(f)*s+z*sin(f)*s+v.xyz*sqrt(1.-x.y);
   return i;
 }
 vec3 F()
 {
   vec3 x=e(texcoord.xy)+D()*t;
   float v=W(x);
   vec3 z=U(r(x)).vyHfppOAPK;
   return z*v;
 }
 vec3 G()
 {
   vec3 x=e(texcoord.xy),v=S(x),s=F(v);
   vec2 z=g(s+vec3(0.,0.,0.)*n);
   vec4 f=texture2DLod(shadowcolor,z,0);
   if(f.w*255.<240.)
     return vec3(0.);
   vec2 r=g(s+vec3(0.,0.,-1.)*n),m=g(s+vec3(1.,0.,0.)*n),t=g(s+vec3(0.,0.,1.)*n),y=g(s+vec3(-1.,0.,0.)*n),w=g(s+vec3(0.,1.,0.)*n),K=g(s+vec3(0.,-1.,0.)*n);
   vec4 d=texture2DLod(shadowcolor,r,0),c=texture2DLod(shadowcolor,m,0),o=texture2DLod(shadowcolor,t,0),J=texture2DLod(shadowcolor,y,0),V=texture2DLod(shadowcolor,w,0),a=texture2DLod(shadowcolor,K,0);
   float l=1000.;
   l=min(l,d.w);
   l=min(l,c.w);
   l=min(l,o.w);
   l=min(l,J.w);
   l=min(l,V.w);
   l=min(l,a.w);
   if(l*255.>240.)
     return vec3(0.);
   float h=1.;
   #ifdef LIGHT_LEAK_FIX
   {
     vec4 R=texture2DLod(shadowcolor1,r,0),B=texture2DLod(shadowcolor1,m,0),Y=texture2DLod(shadowcolor1,t,0),q=texture2DLod(shadowcolor1,y,0),p=texture2DLod(shadowcolor1,w,0),L=texture2DLod(shadowcolor1,K,0);
     h=min(h,R.z);
     h=min(h,B.z);
     h=min(h,Y.z);
     h=min(h,q.z);
     h=min(h,p.z);
     h=min(h,L.z);
     h=saturate(h*80.);
   }
   #endif
   vec3 p=vec3(0.);
   const float T=2.4,B=T;
   for(int R=0;R<GI_SECONDARY_SAMPLES;R++)
     {
       float L=sin(frameTimeCounter*1.1)+v.x*.11+v.y*.12+v.z*.13+R*.1;
       vec3 U=normalize(rand(vec2(L))*2.-1.);
       U.x+=U.x==U.y||U.x==U.z?.01:0.;
       U.y+=U.y==U.z?.01:0.;
       vec3 Y=v+vec3(1.,1.,1.);
       Ray W=MakeRay(F(Y)*i-vec3(1.,1.,1.),U);
       TOuWFelenO q=P(W);
       vec3 H=vec3(1.);
       float D=1000.;
       for(int C=0;C<1;C++)
         {
           vec4 M=vec4(0.);
           float u=0.;
           vec3 Q=vec3(0.);
           vec2 I=vec2(0.);
           float A=.2;
           for(int O=0;O<DIFFUSE_TRACE_LENGTH;O++)
             {
               Q=q.FjeDDzWIWi*n;
               I=g(Q);
               M=texture2DLod(shadowcolor,I,0);
               u=M.w*255.;
               float E=1.-step(.5,abs(u-241.));
               vec3 N=M.xyz*GI_LIGHT_TORCH_INTENSITY;
               p+=N*A*E*(O==0?.25:.5);
               if(u<240.)
                 {
                   break;
                 }
               b(q);
               A=saturate(A*1.3);
             }
           D=distance(q.FjeDDzWIWi.xyz,q.FjeDDzWIWiOrigin.xyz);
           float O=0.;
           vec3 E=-q.GTJIHvOSbK*q.ihCMMEIfgL;
           float N=1.;
           if(abs(dot(q.FjeDDzWIWi-q.FjeDDzWIWiOrigin,E))<1.1)
             N=0.;
           if(u<1.f||u>254.f)
             {
               vec3 j=W.direction;
               if(isEyeInWater>0)
                 j=refract(j,vec3(0.,-1.,0.),1.3333);
               vec3 k=SkyShading(j,worldSunVector,rainStrength);
               k*=saturate(j.y*10.+1.);
               k=DoNightEyeAtNight(k*12.,timeMidnight)*.083333;
               if(length(j)<.1)
                 O=300.;
               vec3 X=k*H,Z=X;
               #ifdef CLOUDS_IN_GI
               CloudPlane(Z,-W.direction,worldLightVector,worldSunVector,colorSunlight,colorSkyUp,X,timeMidnight,false);
               #endif
               X=TintUnderwaterDepth(X);
               X+=StarFlux*timeMidnight;
               p+=X*.1*h;
             }
           if(abs(u-31.)<.1||abs(u-38.)<.1)
             p+=.09*M.xyz*GI_LIGHT_BLOCK_INTENSITY;
           if(u>=32.&&u<=35.)
             {
               float k=0.;
               if(abs(u-32.)<.1)
                 k=max(-E.z,0.);
               if(abs(u-33.)<.1)
                 k=max(E.x,0.);
               if(abs(u-34.)<.1)
                 k=max(E.z,0.);
               if(abs(u-35.)<.1)
                 k=max(-E.x,0.);
               p+=.02*H*k*vec3(1.,.175,.0125)*GI_LIGHT_BLOCK_INTENSITY;
             }
           if(u<240.)
             {
               vec3 k=saturate(M.xyz);
               H*=k;
               vec3 j=-(q.GTJIHvOSbK*q.ihCMMEIfgL),X=G(Q,W.origin+W.direction*D,worldLightVector,j,U,i),Z=DoNightEyeAtNight(X*T*colorSunlight*H*N*h*12.,timeMidnight)/12.;
               p+=Z;
               p+=F(Q,j)*B*mix(vec3(1.),H,vec3(N));
               O=D;
             }
           {
             vec2 k=IntersectSphere(v,W.direction,vec3(0.,1.5,0.),.75);
             if(D>k.y&&k.y>-.5)
               ;
           }
           if(isEyeInWater>0)
             UnderwaterFog(p,O,U,colorSkyUp,colorSunlight);
         }
     }
   p/=float(GI_SECONDARY_SAMPLES);
   return saturate(p/B);
 }
 vec4 C(float v)
 {
   float x=v*v,m=x*v;
   vec4 f;
   f.x=-m+3*x-3*v+1;
   f.y=3*m-6*x+4;
   f.z=-3*m+3*x+3*v+1;
   f.w=m;
   return f/6.f;
 }
 bool C(vec3 v,vec3 f)
 {
   vec3 x=normalize(cross(dFdx(v),dFdy(v))),s=normalize(f-v),m=normalize(s);
   float t=.02+length(v)*.04;
   return distance(v,f)<t;
 }
 vec3 L(sampler2D v,vec2 m)
 {
   vec2 x=m*ScreenSize,i=floor(x-.5)+.5,z=x-i,s=z*z,y=z*s;
   float f=.5;
   vec2 r=-f*y+2.*f*s-f*z,t=(2.-f)*y-(3.-f)*s+1.,w=-(2.-f)*y+(3.-2.*f)*s+f*z,d=f*y-f*s,n=t+w,c=ScreenTexel*(i+w/n);
   vec3 h=texture2DLod(v,vec2(c.x,c.y),0).xyz;
   vec2 K=ScreenTexel*(i-1.),q=ScreenTexel*(i+2.);
   vec4 k=vec4(texture2DLod(v,vec2(c.x,K.y),0).xyz,1.)*(n.x*r.y)+vec4(texture2DLod(v,vec2(K.x,c.y),0).xyz,1.)*(r.x*n.y)+vec4(h,1.)*(n.x*n.y)+vec4(texture2DLod(v,vec2(q.x,c.y),0).xyz,1.)*(d.x*n.y)+vec4(texture2DLod(v,vec2(c.x,q.y),0).xyz,1.)*(n.x*d.y);
   return max(vec3(0.),k.xyz*(1./k.w));
 }
 vec4 C(vec2 v,vec3 f,float x,out vec3 y)
 {
   if(x<.7)
     return vec4(texture2DLod(colortex4,v,0).xyz,1.);
   vec4 i=gbufferProjectionInverse*vec4(UndownscaleTexcoord(texcoord.xy)*2.-1.,x*2.-1.,1.);
   i/=i.w;
   float s=length(i.xyz);
   vec2 z=fract(v*ScreenSize)-.5,m[4]=vec2[4](vec2(0.,0.),vec2(1.,0.),vec2(0.,1.),vec2(1.,1.));
   vec4 r[4];
   for(int t=0;t<4;t++)
     {
       vec2 w=m[t]*ScreenTexel*sign(z),n=LockRenderPixelCoord(v+w);
       float K=texture2DLod(colortex4,n,0).w;
       vec3 d=texture2DLod(colortex4,n,0).xyz;
       float h=K;
       h+=f.z;
       vec4 k=vec4(vec3(texcoord.xy*2.,h),1.)*2.-1.,c=gbufferProjectionInverse*k;
       c.xyz/=c.w;
       float g=length(c.xyz-i.xyz)/(s+.001),l=g>.04?0.:1.;
       r[t]=vec4(d*l,l);
     }
   vec2 t=abs(z);
   vec4 n=mix(r[0],r[1],vec4(t.x)),w=mix(r[2],r[3],vec4(t.x)),c=mix(n,w,vec4(t.y));
   c.xyz/=c.w+.0001;
   return vec4(c.xyz,c.w);
 }
 vec2 C(float v,vec2 f,out float x,out vec3 i,out vec4 s)
 {
   float y;
   vec2 z=F(texcoord.xy,v,y);
   x=texture2D(depthtex1,z).x;
   vec4 t=vec4(UndownscaleTexcoord(texcoord.xy)*2.-1.,x*2.-1.,1.),m=gbufferProjectionInverse*t;
   m.xyz/=m.w;
   vec4 r=gbufferModelViewInverse*vec4(m.xyz,1.);
   s=r;
   s.xyz+=cameraPosition-previousCameraPosition;
   vec4 d=gbufferPreviousModelView*vec4(s.xyz,1.),w=gbufferPreviousProjection*vec4(d.xyz,1.);
   w.xyz/=w.w;
   i=(t.xyz-w.xyz)*.5;
   vec2 n=f.xy-i.xy*.5;
   if(x<.7)
     n=texcoord.xy;
   return n;
 }
 void main()
 {
   vec4 v=vec4(0.);
   eAMCZAKEcI x;
   x.nrlJXyapkV=.1;
   x.QQevGhUGeB=.1;
   x.VSCbvpIaKi=.1;
   x.vyHfppOAPK=vec3(0.);
   if(texcoord.x<HalfScreen.x&&texcoord.y<HalfScreen.y)
     {
       GBufferData f=GetGBufferData(texcoord.xy);
       MaterialMask s=CalculateMasks(f.materialID,texcoord.xy);
       vec4 i=GetViewPosition(texcoord.xy,f.depth),m=gbufferModelViewInverse*vec4(i.xyz,1.),t=gbufferModelViewInverse*vec4(i.xyz,0.);
       vec3 z=normalize(i.xyz),w=normalize(t.xyz),r=normalize((gbufferModelViewInverse*vec4(f.normal,0.)).xyz),y=normalize((gbufferModelViewInverse*vec4(f.geoNormal,0.)).xyz);
       float n=length(i.xyz),c=dot(f.mcLightmap.xy,vec2(.5));
       if(s.grass>.5)
         r=vec3(0.,1.,0.),y=vec3(0.,1.,0.);
       vec4 K=vec4(texcoord.xy,0.,0.);
       vec2 d=texcoord.xy-f.motion.xy*.5,h=d.xy;
       h-=(vec2(mod(frameCounter/2,2.f),mod(frameCounter,2.f))-.5)/vec2(viewWidth,viewHeight)*.125;
       vec3 k;
       vec4 q=C(h.xy,f.motion,f.depth,k);
       eAMCZAKEcI l=U(d.xy);
       float g=1./(saturate(-dot(f.geoNormal,z))*100.+1.);
       vec4 a=vec4(d.xy,0.,0.);
       TemporalJitterProjPosPrevInv(a);
       vec4 p=gbufferPreviousProjectionInverse*vec4(UndownscaleTexcoord(d.xy)*2.-1.,texture2DLod(colortex4,a.xy,0).w*2.-1.,1.);
       p/=p.w;
       vec3 R=(gbufferPreviousModelViewInverse*vec4(p.xyz,1.)).xyz;
       l.nrlJXyapkV+=1.;
       l.nrlJXyapkV=min(l.nrlJXyapkV,float(GI_RESPONSIVENESS));
       vec2 L=1./vec2(viewWidth,viewHeight),J=1.-L;
       float u=0.,j=1.-1./(l.nrlJXyapkV+1.);
       if(q.w<.01||(d.x<L.x||d.x>J.x||d.y<L.y||d.y>J.y)||abs(g-l.QQevGhUGeB)>.1)
         j=0.,u=.99,l.nrlJXyapkV=0.;
       float e;
       vec3 O=texture2DLod(colortex7,texcoord.xy+vec2(0.,HalfScreen.y),0).xyz;
       O=mix(O,q.xyz,vec3(j));
       u=max(u,mix(u,.9,saturate(-f.motion.z*120.)));
       l.QQevGhUGeB=g;
       l.VSCbvpIaKi=mix(u,l.VSCbvpIaKi,mix(j,0.,u));
       O=max(vec3(0.),O);
       v=vec4(O,f.depth);
       x=l;
     }
   x.vyHfppOAPK=mix(F(),G(),vec3(.025));
   gl_FragData[0]=vec4(v);
   {
     eAMCZAKEcI f=U(texcoord.xy);
     x.vPMmNoxUfq=f.vPMmNoxUfq;
     gl_FragData[1]=max(vec4(0.),o(x));
   }
 };




/* DRAWBUFFERS:45 */
