#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"


const bool colortex6MipmapEnabled = false;



in vec4 texcoord;
in vec3 lightVector;

in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;
in float timeSkyDark;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSunglow;
in vec3 colorBouncedSunlight;
in vec3 colorScatteredSunlight;
in vec3 colorTorchlight;
in vec3 colorWaterMurk;
in vec3 colorWaterBlue;
in vec3 colorSkyTint;



in vec3 upVector;



#include "lib/GBufferData.inc"


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),f=ivec2(6144,6144);
 int z=v.x*v.y,y=37748736;
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return t(FloorToInt(floor(pow(float(z),.333333))));
 }
 int t()
 {
   return d(FloorToInt(floor(pow(float(y),.333333))));
 }
 int s=d();
 float m=1./s;
 int i=t();
 float n=1./i;
 vec3 r(vec2 f)
 {
   ivec2 x=ivec2(f.x*v.x,f.y*v.y);
   float y=float(x.y/s),i=float(int(x.x+mod(v.x*y,s))/s);
   i+=floor(v.x*y/s);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(x.x+mod(v.x*y,s),s);
   m.y=mod(x.y,s);
   m.xyz=floor(m.xyz);
   m/=s;
   m.xyz=m.xzy;
   return m;
 }
 vec2 e(vec3 f)
 {
   vec3 i=f.xzy*s;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*s,v.x);
   float c=i.x+x*s;
   r.y=i.y+floor(c/v.x)*s;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 p(vec2 v)
 {
   vec2 x=v;
   x.xy/=.75;
   int z=f.x*f.y;
   ivec2 d=ivec2(x.x*f.x,x.y*f.y);
   float y=float(d.y/i),r=float(int(d.x+mod(f.x*y,i))/i);
   r+=floor(f.x*y/i);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(d.x+mod(f.x*y,i),i);
   m.y=mod(d.y,i);
   m.xyz=floor(m.xyz);
   m/=i;
   m.xyz=m.xzy;
   return m;
 }
 vec2 w(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 m=v.xzy*i;
   m=floor(m+1e-05);
   float x=m.z;
   vec2 r;
   r.x=mod(m.x+x*i,f.x);
   float c=m.x+x*i;
   r.y=m.y+floor(c/f.x)*i;
   r+=.5;
   r/=f;
   r.xy*=.75;
   return r;
 }
 const int c=384,K=c/2-64;
 int l=(c-i)/2;
 float G=floor(cameraPosition.y+.5),u=clamp(G,K-l,K-l),a=G-u;
 vec3 h(vec3 v)
 {
   return v.y+=a,v*=n,v=v+vec3(.5),v;
 }
 vec3 F(vec3 v)
 {
   return v=h(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 T(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v.y-=a,v;
 }
 vec3 g(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 D(vec3 v)
 {
   return v=v-vec3(.5),v*=s,v;
 }
 vec3 D()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,i=floor(v-.0001),f=floor(x-.0001);
   return i-f;
 }
 vec3 D(vec3 v,vec3 f,vec2 x,vec2 m,vec4 d,vec4 i,inout float r,out vec2 z)
 {
   bool y=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   y=!y;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!y||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     r=1.;
   if(i.x==50.||i.x==48.||i.x>=44&&i.x<48||i.x==49.||i.x==52.||i.x==76.)
     {
       r=0.;
       if(f.y<.5)
         r=1.;
     }
   if(i.x==54)
     r=0.;
   if(i.x==51||i.x==53||i.x==55)
     r=0.;
   if(i.x>255)
     r=0.;
   vec3 s,c;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   z=clamp((x.xy-m.xy)*100000.,vec2(0.),vec2(1.));
   float n=.15,K=.15;
   if(i.x==10.||i.x==11.)
     n=.1,K=.1,r=0.;
   if(i.x==51||i.x==55||i.x==53)
     n=.5,K=.1;
   if(i.x==76)
     n=.2,K=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     K=.025,n=.025;
   s=normalize(d.xyz);
   c=normalize(cross(s,f.xyz)*sign(d.w));
   vec3 e=v.xyz+mix(s*n,-s*n,vec3(z.x));
   e.xyz+=mix(c*n,-c*n,vec3(z.y));
   e.xyz-=f.xyz*K;
   return e;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO P(Ray v)
 {
   TOuWFelenO i;
   i.FjeDDzWIWi=floor(v.origin);
   i.FjeDDzWIWiOrigin=i.FjeDDzWIWi;
   i.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.ihCMMEIfgL=sign(v.direction);
   i.HHiebGwFJJ=(sign(v.direction)*(i.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*i.gjulCSuvVu;
   i.GTJIHvOSbK=vec3(0.);
   return i;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 D(const vec3 v,const vec3 i,vec3 m)
 {
   vec3 x=(i+v)*.5,f=(i-v)*.5,s=m-x,r=abs(s);
   r/=f;
   vec3 y=step(r.yzx,r.xyz)*step(r.zxy,r.xyz);
   return y*sign(s);
 }
 bool D(const vec3 v,const vec3 i,Ray f,inout float x,inout vec3 y)
 {
   vec3 z=f.inv_direction*(v-1e-05-f.origin),s=f.inv_direction*(i+1e-05-f.origin),c=min(s,z),d=max(s,z);
   vec2 r=max(c.xx,c.yz);
   float m=max(r.x,r.y);
   r=min(d.xx,d.yz);
   float n=min(r.x,r.y);
   bool t=n>max(m,0.)&&max(m,0.)<x;
   if(t)
     y=D(v,i,f.origin+f.direction*m),x=m;
   return t;
 }
 float W(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 R(eAMCZAKEcI v)
 {
   vec4 i;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   i.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   i.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   i.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return i;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI i;
   vec2 f=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),x=UnpackTwo16BitFrom32Bit(v.w);
   i.nrlJXyapkV=v.x;
   i.QQevGhUGeB=f.y;
   i.VSCbvpIaKi=m.y;
   i.vPMmNoxUfq=x.y*255.;
   i.vyHfppOAPK=pow(vec3(f.x,m.x,x.x),vec3(8.));
   return i;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec3 i=g(T(v)+y+1.+D());
   float x=W(i);
   vec2 f=e(i);
   vec3 z=U(f).vyHfppOAPK;
   return z*x;
 }
 vec3 F(vec3 v,vec3 y)
 {
   vec3 i=g(T(v)+y+1.);
   float x=W(i);
   vec2 f=e(i);
   vec3 z=U(f).vyHfppOAPK;
   return z*x;
 }
 float P(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float i,Ray f,bool y,inout float x,inout vec3 z)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(i>=67.)
     return false;
   r=D(v,v+vec3(1.,1.,1.),f,x,z);
   m=r;
   #else
   if(i<40.)
     return r=D(v,v+vec3(1.,1.,1.),f,x,z),r;
   if(i==40.||i==41.||i>=43.&&i<=54.)
     {
       float s=.5;
       if(i==41.)
         s=.9375;
       r=D(v+vec3(0.,0.,0.),v+vec3(1.,s,1.),f,x,z);
       m=m||r;
     }
   if(i==42.||i>=55.&&i<=66.)
     r=D(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),f,x,z),m=m||r;
   if(i==43.||i==46.||i==47.||i==52.||i==53.||i==54.||i==55.||i==58.||i==59.||i==64.||i==65.||i==66.)
     {
       float s=.5;
       if(i==55.||i==58.||i==59.||i==64.||i==65.||i==66.)
         s=0.;
       r=D(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),f,x,z);
       m=m||r;
     }
   if(i==43.||i==45.||i==48.||i==51.||i==53.||i==54.||i==55.||i==57.||i==60.||i==63.||i==65.||i==66.)
     {
       float s=.5;
       if(i==55.||i==57.||i==60.||i==63.||i==65.||i==66.)
         s=0.;
       r=D(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),f,x,z);
       m=m||r;
     }
   if(i==44.||i==45.||i==49.||i==51.||i==52.||i==54.||i==56.||i==57.||i==61.||i==63.||i==64.||i==66.)
     {
       float s=.5;
       if(i==56.||i==57.||i==61.||i==63.||i==64.||i==66.)
         s=0.;
       r=D(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),f,x,z);
       m=m||r;
     }
   if(i==44.||i==46.||i==50.||i==51.||i==52.||i==53.||i==56.||i==58.||i==62.||i==63.||i==64.||i==65.)
     {
       float s=.5;
       if(i==56.||i==58.||i==62.||i==63.||i==64.||i==65.)
         s=0.;
       r=D(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),f,x,z);
       m=m||r;
     }
   if(i>=67.&&i<=82.)
     r=D(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,f,x,z),m=m||r;
   if(i==68.||i==69.||i==70.||i==72.||i==73.||i==74.||i==76.||i==77.||i==78.||i==80.||i==81.||i==82.)
     {
       float s=8.,c=8.;
       if(i==68.||i==70.||i==72.||i==74.||i==76.||i==78.||i==80.||i==82.)
         s=0.;
       if(i==69.||i==70.||i==73.||i==74.||i==77.||i==78.||i==81.||i==82.)
         c=16.;
       r=D(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,f,x,z);
       m=m||r;
       r=D(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,f,x,z);
       m=m||r;
     }
   if(i>=71.&&i<=82.)
     {
       float s=8.,c=8.;
       if(i>=71.&&i<=74.||i>=79.&&i<=82.)
         c=16.;
       if(i>=75.&&i<=82.)
         s=0.;
       r=D(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,c)/16.,f,x,z);
       m=m||r;
       r=D(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,c)/16.,f,x,z);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(i>=83.&&i<=86.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(i==83.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(i==84.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(i==86.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(i==85.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       r=D(v+s/16.,v+c/16.,f,x,z);
       m=m||r;
     }
   if(i>=87.&&i<=102.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(i>=87.&&i<=94.)
         {
           float n=0.;
           if(i>=91.&&i<=94.)
             n=13.;
           s=vec3(0.,n,0.)/16.;
           c=vec3(16.,n+3.,16.)/16.;
         }
       if(i>=95.&&i<=98.)
         {
           float n=13.;
           if(i==97.||i==98.)
             n=0.;
           s=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(i>=99.&&i<=102.)
         {
           float n=13.;
           if(i==99.||i==100.)
             n=0.;
           s=vec3(n,0.,0.)/16.;
           c=vec3(n+3.,16.,16.)/16.;
         }
       r=D(v+s,v+c,f,x,z);
       m=m||r;
     }
   if(i>=103.&&i<=113.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(i>=103.&&i<=110.)
         {
           float n=float(i)-float(103.)+1.;
           c.y=n*2./16.;
         }
       if(i==111.)
         c.y=.0625;
       if(i==112.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(i==113.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       r=D(v+s,v+c,f,x,z);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 float D(vec3 v,vec3 z,int x,const int m)
 {
   Ray i=MakeRay(v,z);
   TOuWFelenO f=P(i);
   float r=1.,s=100000.;
   vec3 c=vec3(0.);
   for(int y=0;y<m;y++)
     {
       vec3 t=f.FjeDDzWIWi*n;
       vec2 K=w(t);
       vec4 d=texture2DLod(shadowcolor,K,0);
       float e=d.w*255.;
       if(abs(e-36.)<.1||abs(e-38.)<.1)
         {
           continue;
         }
       if(e<240.)
         {
           if(D(f.FjeDDzWIWi,e,i,y==0,s,c))
             {
               r=0.;
               break;
             }
         }
       b(f);
     }
   const float y=m*.33;
   r=mix(r,1.,saturate(s-y));
   return r;
 }
 vec3 H(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),s=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/s;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xyz=FinalShadowProjectionTransformation(i.xyz);
   return i.xyz;
 }
 vec3 F(vec3 v,vec3 i,vec3 f,vec3 x,vec3 s,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float c,y;
   vec3 r=WorldPosToShadowProjPosBias(v,x,.004,c,y),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z),1).x;
   m*=saturate(dot(f,x));
   m*=D(i+x*.01,f,z,3);
   {
     vec4 d=texture2DLod(shadowcolor1,r.xy-vec2(0.,.5),3);
     float n=abs(d.x*256.-(v.y+cameraPosition.y)),K=GetCausticsComposite(v,f,n),t=shadow2DLod(shadowtex0,vec3(r.xy-vec2(0.,.5),r.z+1e-06),3).x;
     m=mix(m,m*K,1.-t);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 i,vec3 f,vec3 x,vec3 s,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 r=T(v);
   r+=1.;
   r-=Fract01(cameraPosition+.5);
   float c,y;
   vec3 m=WorldPosToShadowProjPosBias(r+x*.99,x,.004,c,y),n=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   n*=saturate(dot(f,x));
   n*=D(i+x*.99,f,z,3);
   n=TintUnderwaterDepth(n);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   n=mix(n,n*e,vec3(1.-t));
   #endif
   return n*(1.-rainStrength);
 }
 vec3 P(vec3 v,vec3 i,vec3 f,vec3 x,vec3 s,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float c,y;
   vec3 m=WorldPosToShadowProjPosBias(v,x,.004,c,y);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z-.0006*n),2).x;
   r*=saturate(dot(f,x));
   r*=D(i+x*.01,f,z,3);
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z-.0006*n),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   r=mix(r,r*e,vec3(1.-t));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 V(vec2 i)
 {
   vec2 v=vec2(i.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(i.x<2./viewWidth||i.x>1.-2./viewWidth||i.y<2./viewHeight||i.y>1.-2./viewHeight)
     ;
   else
      v+=m[frameCounter/2%16]*.5;
   v=(floor(v*64.)+.5)/64.;
   vec3 r=texture2D(noisetex,v).xyz,x=vec3(sqrt(.2),sqrt(2.),1.61803);
   r=mod(r+float(frameCounter%2)*.5,vec3(1.));
   return r;
 }
 float H(float v,float z)
 {
   return exp(-pow(v/(.9*z),2.));
 }
 float R(vec3 v,vec3 z)
 {
   return dot(abs(v-z),vec3(.3333));
 }
 vec3 Q(vec2 i)
 {
   vec2 v=vec2(i.xy*ScreenSize)/64.;
   const vec2 f[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(i.x<2./viewWidth||i.x>1.-2./viewWidth||i.y<2./viewHeight||i.y>1.-2./viewHeight)
     ;
   v=(floor(v*64.)+.5)/64.;
   vec3 r=texture2D(noisetex,v).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   r=mod(r+vec3(s)*mod(frameCounter,64.f),vec3(1.));
   return r;
 }
 vec3 F(float v,float f,float x,vec3 i)
 {
   vec3 r;
   r.x=x*cos(v);
   r.y=x*sin(v);
   r.z=f;
   vec3 s=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),c=normalize(cross(i,vec3(0.,1.,1.))),m=cross(c,i);
   return c*r.x+m*r.y+i*r.z;
 }
 vec3 F(vec2 v,float i,vec3 z)
 {
   float x=2*3.14159*v.x,s=sqrt((1-v.y)/(1+(i*i-1)*v.y)),f=sqrt(1-s*s);
   return F(x,s,f,z);
 }
 float B(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 B(in vec2 v,in float i,in vec3 z)
 {
   float s=B(i),x=2*3.14159*v.x,f=pow(v.y,1.f/(s+1.f)),c=sqrt(1-f*f);
   return F(x,f,c,z);
 }
 float S(vec2 v)
 {
   return texture2DLod(colortex1,v+HalfScreen,0).w;
 }
 float B(float v,float i)
 {
   return v/(i*20.01+1.);
 }
 vec2 Q(vec2 i,float v)
 {
   vec2 x=i;
   mat2 m=mat2(cos(v),-sin(v),sin(v),cos(v));
   i=m*i;
   return i;
 }
 vec4 B(sampler2D v,float x,bool i,float f,float s,float z,float y)
 {
   GBufferData m=GetGBufferData(texcoord.xy);
   GBufferDataTransparent r=GetGBufferDataTransparent(texcoord.xy);
   bool c=r.depth<m.depth;
   if(c)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 d=GetViewPosition(texcoord.xy,m.depth),n=gbufferModelViewInverse*vec4(d.xyz,1.),K=gbufferModelViewInverse*vec4(d.xyz,0.);
   vec3 t=normalize(d.xyz),e=normalize(K.xyz),u=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float l=GetDepthLinear(texcoord.xy),a=dot(-t,m.normal.xyz),G=1.-m.smoothness,w=G*G,p=P(m.smoothness,m.metalness);
   vec4 F=texture2DLod(v,texcoord.xy+HalfScreen,0);
   float T=Luminance(F.xyz);
   if(p<.001)
     return F;
   float g=x*.9;
   g*=min(w*20.,1.1);
   g*=mix(F.w,1.,.2);
   vec2 H=vec2(0.);
   if(i)
     {
       vec2 W=BlueNoiseTemporal(texcoord.xy).xy*.99+.005;
       H=W-.5;
     }
   float W=BlueNoiseTemporal(texcoord.xy).x,S=1.1,b=B(f,m.totalTexGrad)/(w+.0001),R=B(s*.5,m.totalTexGrad);
   vec4 J=vec4(0.),o=vec4(0.);
   float U=0.;
   vec4 V=vec4(vec3(z),1.);
   V.xyz=vec3(1.);
   V.xyz*=F.w*.95+.05;
   float h=m.smoothness;
   vec2 Y=normalize(cross(m.normal,t).xy),L=Q(Y,1.5708);
   float D=1.-pow(1.-saturate(a),1.);
   Y*=mix(.1075,.5,D);
   L*=mix(mix(.7,.7,w),.5,D);
   g*=1.8;
   vec3 q=reflect(-t,m.normal);
   int I=0;
   for(int A=-1;A<=1;A++)
     {
       for(int O=-1;O<=1;O++)
         {
           vec2 M=vec2(A,O)+H;
           M=M.x*Y+M.y*L;
           M*=g*ScreenTexel;
           vec2 C=texcoord.xy+M.xy;
           float E=length(M*ScreenSize);
           C=clamp(C,4.*ScreenTexel,1.-4.*ScreenTexel);
           vec4 k=texture2DLod(v,C+HalfScreen,0);
           vec3 j=GetNormals(C);
           float N=GetDepthLinear(C),Z=pow(saturate(dot(q,reflect(-t,j))),115./w),X=exp(-(abs(N-l)*S)),ab=Z*X;
           J+=vec4(pow(length(k.xyz),V.x)*normalize(k.xyz+1e-10),k.w)*ab;
           U+=ab;
           o+=k;
           I++;
         }
     }
   J/=U+1e-07;
   J.xyz=pow(length(J.xyz),1./V.x)*normalize(J.xyz+1e-08);
   vec4 k=J;
   if(U<.001)
     k=F;
   return k;
 }
 void main()
 {
   vec4 i=texture2DLod(colortex7,texcoord.xy+HalfScreen,4);
   vec3 v=pow(texture2DLod(colortex1,texcoord.xy+HalfScreen,2).xyz,vec3(2.2)),s=GetViewPosition(texcoord.xy,GetDepth(texcoord.xy)).xyz,z=GetNormals(texcoord.xy);
   float m=pow(1.-saturate(dot(-normalize(s),z)),5.);
   i.xyz*=m;
   float x=dot(max(vec3(0.),vec3(i.xyz-v.xyz*20.)),vec3(240.));
   vec4 f=texture2DLod(colortex7,texcoord.xy+HalfScreen,0);
   f=B(colortex7,30.,false,180.,40.,.1,0.);
   f=max(f,vec4(0.));
   gl_FragData[0]=vec4(f);
 };




/* DRAWBUFFERS:7 */
