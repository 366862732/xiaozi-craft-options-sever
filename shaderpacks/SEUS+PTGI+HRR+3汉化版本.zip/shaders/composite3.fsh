#version 330 compatibility




/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#include "lib/Uniforms.inc"
#include "lib/Common.inc"





in vec4 texcoord;
in vec3 lightVector;

in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;
in float timeSkyDark;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorSunglow;
in vec3 colorBouncedSunlight;
in vec3 colorScatteredSunlight;
in vec3 colorTorchlight;
in vec3 colorWaterMurk;
in vec3 colorWaterBlue;
in vec3 colorSkyTint;



in vec3 upVector;



#include "lib/GBufferData.inc"


 const float x=1./float(8192);
 ivec2 v=ivec2(viewWidth,viewHeight),f=ivec2(6144,6144);
 int z=v.x*v.y,y=37748736;
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int d(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int d()
 {
   return t(FloorToInt(floor(pow(float(z),.333333))));
 }
 int t()
 {
   return d(FloorToInt(floor(pow(float(y),.333333))));
 }
 int s=d();
 float m=1./s;
 int i=t();
 float n=1./i;
 vec3 e(vec2 f)
 {
   ivec2 x=ivec2(f.x*v.x,f.y*v.y);
   float y=float(x.y/s),i=float(int(x.x+mod(v.x*y,s))/s);
   i+=floor(v.x*y/s);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(x.x+mod(v.x*y,s),s);
   m.y=mod(x.y,s);
   m.xyz=floor(m.xyz);
   m/=s;
   m.xyz=m.xzy;
   return m;
 }
 vec2 r(vec3 f)
 {
   vec3 i=f.xzy*s;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*s,v.x);
   float c=i.x+x*s;
   r.y=i.y+floor(c/v.x)*s;
   r+=.5;
   r/=v;
   return r;
 }
 vec3 p(vec2 v)
 {
   vec2 x=v;
   x.xy/=.75;
   int z=f.x*f.y;
   ivec2 d=ivec2(x.x*f.x,x.y*f.y);
   float y=float(d.y/i),r=float(int(d.x+mod(f.x*y,i))/i);
   r+=floor(f.x*y/i);
   vec3 m=vec3(0.,0.,r);
   m.x=mod(d.x+mod(f.x*y,i),i);
   m.y=mod(d.y,i);
   m.xyz=floor(m.xyz);
   m/=i;
   m.xyz=m.xzy;
   return m;
 }
 vec2 w(vec3 v)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec3 m=v.xzy*i;
   m=floor(m+1e-05);
   float x=m.z;
   vec2 r;
   r.x=mod(m.x+x*i,f.x);
   float c=m.x+x*i;
   r.y=m.y+floor(c/f.x)*i;
   r+=.5;
   r/=f;
   r.xy*=.75;
   return r;
 }
 const int c=384,K=c/2-64;
 int l=(c-i)/2;
 float G=floor(cameraPosition.y+.5),u=clamp(G,K-l,K-l),a=G-u;
 vec3 h(vec3 v)
 {
   return v.y+=a,v*=n,v=v+vec3(.5),v;
 }
 vec3 F(vec3 v)
 {
   return v=h(v),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 T(vec3 v)
 {
   return v=v-vec3(.5),v*=i,v.y-=a,v;
 }
 vec3 g(vec3 v)
 {
   return v*=m,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 D(vec3 v)
 {
   return v=v-vec3(.5),v*=s,v;
 }
 vec3 D()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,i=floor(v-.0001),f=floor(x-.0001);
   return i-f;
 }
 vec3 D(vec3 v,vec3 f,vec2 x,vec2 m,vec4 d,vec4 i,inout float r,out vec2 z)
 {
   bool y=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   y=!y;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!y||i.x==20.||i.x==171.||min(abs(f.x),abs(f.z))>.2)
     r=1.;
   if(i.x==50.||i.x==48.||i.x>=44&&i.x<48||i.x==49.||i.x==52.||i.x==76.)
     {
       r=0.;
       if(f.y<.5)
         r=1.;
     }
   if(i.x==54)
     r=0.;
   if(i.x==51||i.x==53||i.x==55)
     r=0.;
   if(i.x>255)
     r=0.;
   vec3 s,c;
   if(f.x>.5)
     s=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(f.x<-.5)
       s=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(f.y>.5)
         s=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(f.y<-.5)
           s=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(f.z>.5)
             s=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(f.z<-.5)
               s=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   z=clamp((x.xy-m.xy)*100000.,vec2(0.),vec2(1.));
   float n=.15,K=.15;
   if(i.x==10.||i.x==11.)
     n=.1,K=.1,r=0.;
   if(i.x==51||i.x==55||i.x==53)
     n=.5,K=.1;
   if(i.x==76)
     n=.2,K=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     K=.025,n=.025;
   s=normalize(d.xyz);
   c=normalize(cross(s,f.xyz)*sign(d.w));
   vec3 e=v.xyz+mix(s*n,-s*n,vec3(z.x));
   e.xyz+=mix(c*n,-c*n,vec3(z.y));
   e.xyz-=f.xyz*K;
   return e;
 }struct TOuWFelenO{vec3 FjeDDzWIWi;vec3 FjeDDzWIWiOrigin;vec3 gjulCSuvVu;vec3 ihCMMEIfgL;vec3 HHiebGwFJJ;vec3 GTJIHvOSbK;};
 TOuWFelenO P(Ray v)
 {
   TOuWFelenO i;
   i.FjeDDzWIWi=floor(v.origin);
   i.FjeDDzWIWiOrigin=i.FjeDDzWIWi;
   i.gjulCSuvVu=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.ihCMMEIfgL=sign(v.direction);
   i.HHiebGwFJJ=(sign(v.direction)*(i.FjeDDzWIWi-v.origin)+sign(v.direction)*.5+.5)*i.gjulCSuvVu;
   i.GTJIHvOSbK=vec3(0.);
   return i;
 }
 void b(inout TOuWFelenO v)
 {
   v.GTJIHvOSbK=step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.yzx)*step(v.HHiebGwFJJ.xyz,v.HHiebGwFJJ.zxy),v.HHiebGwFJJ+=v.GTJIHvOSbK*v.gjulCSuvVu,v.FjeDDzWIWi+=v.GTJIHvOSbK*v.ihCMMEIfgL;
 }
 vec3 D(const vec3 v,const vec3 i,vec3 m)
 {
   vec3 x=(i+v)*.5,f=(i-v)*.5,s=m-x,r=abs(s);
   r/=f;
   vec3 y=step(r.yzx,r.xyz)*step(r.zxy,r.xyz);
   return y*sign(s);
 }
 bool D(const vec3 v,const vec3 i,Ray f,inout float x,inout vec3 y)
 {
   vec3 z=f.inv_direction*(v-1e-05-f.origin),s=f.inv_direction*(i+1e-05-f.origin),c=min(s,z),d=max(s,z);
   vec2 r=max(c.xx,c.yz);
   float m=max(r.x,r.y);
   r=min(d.xx,d.yz);
   float n=min(r.x,r.y);
   bool t=n>max(m,0.)&&max(m,0.)<x;
   if(t)
     y=D(v,i,f.origin+f.direction*m),x=m;
   return t;
 }
 float W(vec3 v)
 {
   return 1.;
 }struct eAMCZAKEcI{float nrlJXyapkV;float vPMmNoxUfq;float QQevGhUGeB;float VSCbvpIaKi;vec3 vyHfppOAPK;};
 vec4 R(eAMCZAKEcI v)
 {
   vec4 i;
   v.vyHfppOAPK=max(vec3(0.),v.vyHfppOAPK);
   i.x=v.nrlJXyapkV;
   v.vyHfppOAPK=pow(v.vyHfppOAPK,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.vyHfppOAPK.x,v.QQevGhUGeB);
   i.z=PackTwo16BitTo32Bit(v.vyHfppOAPK.y,v.VSCbvpIaKi);
   i.w=PackTwo16BitTo32Bit(v.vyHfppOAPK.z,v.vPMmNoxUfq/255.);
   return i;
 }
 eAMCZAKEcI o(vec4 v)
 {
   eAMCZAKEcI i;
   vec2 f=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),x=UnpackTwo16BitFrom32Bit(v.w);
   i.nrlJXyapkV=v.x;
   i.QQevGhUGeB=f.y;
   i.VSCbvpIaKi=m.y;
   i.vPMmNoxUfq=x.y*255.;
   i.vyHfppOAPK=pow(vec3(f.x,m.x,x.x),vec3(8.));
   return i;
 }
 eAMCZAKEcI U(vec2 v)
 {
   return v=(floor(v*ScreenSize)+.5)*ScreenTexel,o(texture2DLod(colortex5,v,0));
 }
 vec3 D(vec3 v,vec3 y)
 {
   vec3 i=g(T(v)+y+1.+D());
   float x=W(i);
   vec2 f=r(i);
   vec3 z=U(f).vyHfppOAPK;
   return z*x;
 }
 vec3 F(vec3 v,vec3 y)
 {
   vec3 i=g(T(v)+y+1.);
   float x=W(i);
   vec2 f=r(i);
   vec3 z=U(f).vyHfppOAPK;
   return z*x;
 }
 float P(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool D(vec3 v,float x,Ray i,bool f,inout float y,inout vec3 z)
 {
   bool r=false,m=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(f)
     return false;
   if(x>=67.)
     return false;
   m=D(v,v+vec3(1.,1.,1.),i,y,z);
   r=m;
   #else
   if(x<40.)
     return m=D(v,v+vec3(1.,1.,1.),i,y,z),m;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float s=.5;
       if(x==41.)
         s=.9375;
       m=D(v+vec3(0.,0.,0.),v+vec3(1.,s,1.),i,y,z);
       r=r||m;
     }
   if(x==42.||x>=55.&&x<=66.)
     m=D(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,y,z),r=r||m;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float s=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         s=0.;
       m=D(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),i,y,z);
       r=r||m;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float s=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         s=0.;
       m=D(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),i,y,z);
       r=r||m;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float s=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         s=0.;
       m=D(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),i,y,z);
       r=r||m;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float s=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         s=0.;
       m=D(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),i,y,z);
       r=r||m;
     }
   if(x>=67.&&x<=82.)
     m=D(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,y,z),r=r||m;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float s=8.,c=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         s=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         c=16.;
       m=D(v+vec3(s,6.,7.)/16.,v+vec3(c,9.,9.)/16.,i,y,z);
       r=r||m;
       m=D(v+vec3(s,12.,7.)/16.,v+vec3(c,15.,9.)/16.,i,y,z);
       r=r||m;
     }
   if(x>=71.&&x<=82.)
     {
       float s=8.,c=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         c=16.;
       if(x>=75.&&x<=82.)
         s=0.;
       m=D(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,c)/16.,i,y,z);
       r=r||m;
       m=D(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,c)/16.,i,y,z);
       r=r||m;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 s=vec3(0),c=vec3(0);
       if(x==83.)
         s=vec3(0,0,0),c=vec3(16,16,3);
       if(x==84.)
         s=vec3(0,0,13),c=vec3(16,16,16);
       if(x==86.)
         s=vec3(0,0,0),c=vec3(3,16,16);
       if(x==85.)
         s=vec3(13,0,0),c=vec3(16,16,16);
       m=D(v+s/16.,v+c/16.,i,y,z);
       r=r||m;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float n=0.;
           if(x>=91.&&x<=94.)
             n=13.;
           s=vec3(0.,n,0.)/16.;
           c=vec3(16.,n+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float n=13.;
           if(x==97.||x==98.)
             n=0.;
           s=vec3(0.,0.,n)/16.;
           c=vec3(16.,16.,n+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float n=13.;
           if(x==99.||x==100.)
             n=0.;
           s=vec3(n,0.,0.)/16.;
           c=vec3(n+3.,16.,16.)/16.;
         }
       m=D(v+s,v+c,i,y,z);
       r=r||m;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 s=vec3(0.),c=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float n=float(x)-float(103.)+1.;
           c.y=n*2./16.;
         }
       if(x==111.)
         c.y=.0625;
       if(x==112.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,1.,15.)/16.;
       if(x==113.)
         s=vec3(1.,0.,1.)/16.,c=vec3(15.,.5,15.)/16.;
       m=D(v+s,v+c,i,y,z);
       r=r||m;
     }
   #endif
   #endif
   return r;
 }
 float D(vec3 v,vec3 i,int y,const int m)
 {
   Ray x=MakeRay(v,i);
   TOuWFelenO f=P(x);
   float r=1.,s=100000.;
   vec3 z=vec3(0.);
   for(int c=0;c<m;c++)
     {
       vec3 t=f.FjeDDzWIWi*n;
       vec2 K=w(t);
       vec4 d=texture2DLod(shadowcolor,K,0);
       float e=d.w*255.;
       if(abs(e-36.)<.1||abs(e-38.)<.1)
         {
           continue;
         }
       if(e<240.)
         {
           if(D(f.FjeDDzWIWi,e,x,c==0,s,z))
             {
               r=0.;
               break;
             }
         }
       b(f);
     }
   const float c=m*.33;
   r=mix(r,1.,saturate(s-c));
   return r;
 }
 vec3 H(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float s=sqrt(x.x*x.x+x.y*x.y),i=1.f-SHADOW_MAP_BIAS+s*SHADOW_MAP_BIAS;
   x.xy*=.95f/i;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xyz=FinalShadowProjectionTransformation(x.xyz);
   return x.xyz;
 }
 vec3 F(vec3 v,vec3 x,vec3 i,vec3 y,vec3 s,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v-=Fract01(cameraPosition+.5);
   float f,c;
   vec3 r=WorldPosToShadowProjPosBias(v,y,.004,f,c),m=vec3(1.)*shadow2DLod(shadowtex0,vec3(r.xy,r.z),1).x;
   m*=saturate(dot(i,y));
   m*=D(x+y*.01,i,z,3);
   {
     vec4 d=texture2DLod(shadowcolor1,r.xy-vec2(0.,.5),3);
     float n=abs(d.x*256.-(v.y+cameraPosition.y)),K=GetCausticsComposite(v,i,n),t=shadow2DLod(shadowtex0,vec3(r.xy-vec2(0.,.5),r.z+1e-06),3).x;
     m=mix(m,m*K,1.-t);
   }
   m=TintUnderwaterDepth(m);
   return m*(1.-rainStrength);
 }
 vec3 H(vec3 v,vec3 x,vec3 i,vec3 y,vec3 s,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 r=T(v);
   r+=1.;
   r-=Fract01(cameraPosition+.5);
   float f,c;
   vec3 m=WorldPosToShadowProjPosBias(r+y*.99,y,.004,f,c),n=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z),1).x;
   n*=saturate(dot(i,y));
   n*=D(x+y*.99,i,z,3);
   n=TintUnderwaterDepth(n);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   n=mix(n,n*e,vec3(1.-t));
   #endif
   return n*(1.-rainStrength);
 }
 vec3 P(vec3 v,vec3 x,vec3 i,vec3 y,vec3 s,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   float f,c;
   vec3 m=WorldPosToShadowProjPosBias(v,y,.004,f,c);
   float n=.5;
   vec3 r=vec3(1.)*shadow2DLod(shadowtex0,vec3(m.xy,m.z-.0006*n),2).x;
   r*=saturate(dot(i,y));
   r*=D(x+y*.01,i,z,3);
   r=TintUnderwaterDepth(r);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(m.xy-vec2(.5,0.),m.z-.0006*n),3).x;
   vec3 e=texture2DLod(shadowcolor,vec2(m.xy-vec2(.5,0.)),3).xyz;
   e*=e;
   r=mix(r,r*e,vec3(1.-t));
   #endif
   return r*(1.-rainStrength);
 }
 vec3 V(vec2 v)
 {
   vec2 x=vec2(v.xy*vec2(viewWidth,viewHeight));
   x*=1./64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   else
      x+=m[frameCounter/2%16]*.5;
   x=(floor(x*64.)+.5)/64.;
   vec3 i=texture2D(noisetex,x).xyz,c=vec3(sqrt(.2),sqrt(2.),1.61803);
   i=mod(i+float(frameCounter%2)*.5,vec3(1.));
   return i;
 }
 float H(float v,float z)
 {
   return exp(-pow(v/(.9*z),2.));
 }
 float R(vec3 v,vec3 z)
 {
   return dot(abs(v-z),vec3(.3333));
 }
 vec3 Q(vec2 v)
 {
   vec2 x=vec2(v.xy*ScreenSize)/64.;
   const vec2 i[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   x=(floor(x*64.)+.5)/64.;
   vec3 r=texture2D(noisetex,x).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   r=mod(r+vec3(s)*mod(frameCounter,64.f),vec3(1.));
   return r;
 }
 vec3 F(float v,float i,float y,vec3 x)
 {
   vec3 f;
   f.x=y*cos(v);
   f.y=y*sin(v);
   f.z=i;
   vec3 s=abs(x.y)<.999?vec3(0,0,1):vec3(1,0,0),c=normalize(cross(x,vec3(0.,1.,1.))),r=cross(c,x);
   return c*f.x+r*f.y+x*f.z;
 }
 vec3 F(vec2 v,float x,vec3 z)
 {
   float i=2*3.14159*v.x,y=sqrt((1-v.y)/(1+(x*x-1)*v.y)),s=sqrt(1-y*y);
   return F(i,y,s,z);
 }
 float B(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 B(in vec2 v,in float x,in vec3 z)
 {
   float s=B(x),i=2*3.14159*v.x,y=pow(v.y,1.f/(s+1.f)),c=sqrt(1-y*y);
   return F(i,y,c,z);
 }
 float S(vec2 v)
 {
   return texture2DLod(colortex1,v+HalfScreen,0).w;
 }
 float B(float v,float x)
 {
   return v/(x*20.01+1.);
 }
 vec2 Q(vec2 v,float x)
 {
   vec2 s=v;
   mat2 m=mat2(cos(x),-sin(x),sin(x),cos(x));
   v=m*v;
   return v;
 }
 vec4 B(sampler2D v,float y,bool x,float i,float s,float z,float f)
 {
   GBufferData m=GetGBufferData(texcoord.xy);
   GBufferDataTransparent r=GetGBufferDataTransparent(texcoord.xy);
   bool c=r.depth<m.depth;
   if(c)
     m.normal=r.normal,m.smoothness=r.smoothness,m.metalness=0.,m.mcLightmap=r.mcLightmap,m.depth=r.depth;
   vec4 d=GetViewPosition(texcoord.xy,m.depth),n=gbufferModelViewInverse*vec4(d.xyz,1.),K=gbufferModelViewInverse*vec4(d.xyz,0.);
   vec3 t=normalize(d.xyz),e=normalize(K.xyz),u=normalize((gbufferModelViewInverse*vec4(m.normal,0.)).xyz);
   float l=GetDepthLinear(texcoord.xy),a=dot(-t,m.normal.xyz),G=1.-m.smoothness,w=G*G,p=P(m.smoothness,m.metalness);
   vec4 F=texture2DLod(v,texcoord.xy+HalfScreen,0);
   float T=Luminance(F.xyz);
   if(p<.001)
     return F;
   float g=y*.9;
   g*=min(w*20.,1.1);
   g*=mix(F.w,1.,.2);
   vec2 H=vec2(0.);
   if(x)
     {
       vec2 W=BlueNoiseTemporal(texcoord.xy).xy*.99+.005;
       H=W-.5;
     }
   float W=BlueNoiseTemporal(texcoord.xy).x,S=1.1,b=B(i,m.totalTexGrad)/(w+.0001),R=B(s*.5,m.totalTexGrad);
   vec4 J=vec4(0.),o=vec4(0.);
   float U=0.;
   vec4 V=vec4(vec3(z),1.);
   V.xyz=vec3(1.);
   V.xyz*=F.w*.95+.05;
   float h=m.smoothness;
   vec2 Y=normalize(cross(m.normal,t).xy),L=Q(Y,1.5708);
   float D=1.-pow(1.-saturate(a),1.);
   Y*=mix(.1075,.5,D);
   L*=mix(mix(.7,.7,w),.5,D);
   g*=1.8;
   vec3 q=reflect(-t,m.normal);
   int I=0;
   for(int A=-1;A<=1;A++)
     {
       for(int O=-1;O<=1;O++)
         {
           vec2 M=vec2(A,O)+H;
           M=M.x*Y+M.y*L;
           M*=g*ScreenTexel;
           vec2 C=texcoord.xy+M.xy;
           float E=length(M*ScreenSize);
           C=clamp(C,4.*ScreenTexel,1.-4.*ScreenTexel);
           vec4 k=texture2DLod(v,C+HalfScreen,0);
           vec3 j=GetNormals(C);
           float N=GetDepthLinear(C),Z=pow(saturate(dot(q,reflect(-t,j))),115./w),X=exp(-(abs(N-l)*S)),ab=Z*X;
           J+=vec4(pow(length(k.xyz),V.x)*normalize(k.xyz+1e-10),k.w)*ab;
           U+=ab;
           o+=k;
           I++;
         }
     }
   J/=U+1e-07;
   J.xyz=pow(length(J.xyz),1./V.x)*normalize(J.xyz+1e-08);
   vec4 k=J;
   if(U<.001)
     k=F;
   return k;
 }
 void main()
 {
   vec4 v=texture2DLod(colortex7,texcoord.xy+HalfScreen,4);
   vec3 x=pow(texture2DLod(colortex1,texcoord.xy+HalfScreen,2).xyz,vec3(2.2)),s=GetViewPosition(texcoord.xy,GetDepth(texcoord.xy)).xyz,z=GetNormals(texcoord.xy);
   float m=pow(1.-saturate(dot(-normalize(s),z)),5.);
   v.xyz*=m;
   float r=dot(max(vec3(0.),vec3(v.xyz-x.xyz*20.)),vec3(240.));
   vec4 i=texture2DLod(colortex7,texcoord.xy+HalfScreen,0);
   vec2 f=1.-abs(texcoord.xy*2.-1.);
   f=saturate(f*10.);
   float c=min(f.x,f.y);
   gl_FragData[0]=vec4(i);
 };




/* DRAWBUFFERS:7 */
