#version 430
#define comp
#define DIM_END

#include "../Passes/C4_CopyClouds.comp"