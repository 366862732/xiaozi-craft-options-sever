#version 430 compatibility
#define frag
#define DIM_END

#include "../Passes/C6_PostProcess0.frag"
