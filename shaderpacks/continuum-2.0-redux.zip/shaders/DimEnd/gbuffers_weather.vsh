#version 430 compatibility

#define vert
#define gbuffers_weather
#define DIM_END

#include "../Passes/GBuffersWeather.vert"