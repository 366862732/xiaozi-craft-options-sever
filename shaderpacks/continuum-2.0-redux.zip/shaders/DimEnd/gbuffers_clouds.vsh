#version 430 compatibility
#define vert 
#define DIM_END

#include "../Passes/GBuffersDiscard.vert"
