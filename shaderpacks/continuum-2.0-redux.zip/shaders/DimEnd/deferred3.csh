#version 430 compatibility
#define comp
#define DIM_END

#include "../Passes/D3_GenSH.comp"