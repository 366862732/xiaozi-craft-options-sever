#version 430 compatibility
#define frag
#define DIM_END
 
#include "../Passes/D4_RenderGI.frag"