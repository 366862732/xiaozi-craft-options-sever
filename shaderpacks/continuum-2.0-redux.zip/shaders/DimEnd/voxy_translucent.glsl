#define DIM_END
#include "../Passes/GBuffersLODTranslucent.glsl"