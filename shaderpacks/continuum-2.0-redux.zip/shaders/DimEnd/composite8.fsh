#version 430 compatibility
#define comp
#define DIM_END

#include "../Passes/C8_TAA.frag"
