#version 430 compatibility

#define frag
#define gbuffers_entities
#define DIM_END

#include "../Passes/GBuffersMain.frag"
