#version 430 compatibility

#define frag
#define gbuffers_hand
#define DIM_END

#include "../Passes/GBuffersMain.frag"
