#version 430 compatibility
#define frag
#define DIM_END

#include "../Passes/D2_RenderEquirectSkyImg.frag"