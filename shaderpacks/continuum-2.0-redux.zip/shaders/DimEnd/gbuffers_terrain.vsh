#version 430 compatibility

#define vert
#define gbuffers_terrain
#define DIM_END

#include "../Passes/GBuffersMain.vert"
