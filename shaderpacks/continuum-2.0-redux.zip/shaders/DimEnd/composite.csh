#version 430
#define comp
#define DIM_END

#include "../Passes/C0_ConstructDepth.comp"