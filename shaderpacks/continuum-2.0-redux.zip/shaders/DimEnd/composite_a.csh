#version 430
#define comp
#define DIM_END

#include "../Passes/C0A_GenerateFroxels.comp"