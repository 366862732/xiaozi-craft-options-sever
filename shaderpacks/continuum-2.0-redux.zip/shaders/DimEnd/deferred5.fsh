#version 430 compatibility
#define frag
#define DIM_END
 
#include "../Passes/D5_FilterGIX.frag"