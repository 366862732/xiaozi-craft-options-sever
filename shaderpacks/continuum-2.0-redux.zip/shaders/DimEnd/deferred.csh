#version 430 compatibility
#define comp
#define DIM_END

#include "../Passes/D0_ConstructDepth.comp"