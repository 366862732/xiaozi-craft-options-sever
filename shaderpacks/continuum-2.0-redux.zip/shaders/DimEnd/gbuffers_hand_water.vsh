#version 430 compatibility

#define vert
#define gbuffers_hand_water
#define DIM_END

#include "../Passes/GBuffersMainTranslucent.vert"