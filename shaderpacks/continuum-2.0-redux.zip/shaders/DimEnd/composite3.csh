#version 430
#define comp
#define DIM_END

#include "../Passes/C3_UpscaleClouds.comp"