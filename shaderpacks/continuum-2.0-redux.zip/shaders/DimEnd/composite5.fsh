#version 430 compatibility
#define frag
#define DIM_END

#include "../Passes/C5_CompositeScene.frag"
