#version 430 compatibility
#define comp
#define DIM_END

#include "../Passes/B0_InitSSBOs.comp"