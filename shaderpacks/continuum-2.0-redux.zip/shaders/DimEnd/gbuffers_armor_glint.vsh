#version 430 compatibility

#define vert
#define gbuffers_armor_glint
#define DIM_END

#include "../Passes/GBuffersMain.vert"
