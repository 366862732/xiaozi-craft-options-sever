#version 430 compatibility

#define frag
#define gbuffers_textured
#define DIM_END

#include "../Passes/GBuffersMain.frag"
