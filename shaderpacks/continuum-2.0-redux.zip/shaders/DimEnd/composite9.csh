#version 430 compatibility
#define comp
#define DIM_END

#include "../Passes/C9_CopyFroxels.comp"