#version 430 compatibility
#define vert
#define DIM_END

#include "../Passes/Templates/PostSimple.vert"