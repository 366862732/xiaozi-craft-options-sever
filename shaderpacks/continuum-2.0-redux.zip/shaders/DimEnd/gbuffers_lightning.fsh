#version 430 compatibility

#define frag
#define gbuffers_lightning
#define DIM_END

#include "../Passes/GBuffersMain.frag"
