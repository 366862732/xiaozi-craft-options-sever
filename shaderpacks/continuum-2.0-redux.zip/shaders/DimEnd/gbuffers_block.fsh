#version 430 compatibility

#define frag
#define gbuffers_block
#define DIM_END

#include "../Passes/GBuffersMain.frag"
