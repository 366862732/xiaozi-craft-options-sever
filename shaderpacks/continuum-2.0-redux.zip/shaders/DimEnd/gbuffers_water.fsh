#version 430 compatibility

#define frag
#define gbuffers_water
#define DIM_END

#include "../Passes/GBuffersMainTranslucent.frag"
