#version 430 compatibility

#define vsh
#define DIM_END

#include "../Passes/Shadow.vert"
