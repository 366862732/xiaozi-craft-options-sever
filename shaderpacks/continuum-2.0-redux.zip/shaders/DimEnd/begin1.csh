#version 430
#define comp
#define DIM_END

#include "../Passes/B1_GenWaveFieldX.comp"