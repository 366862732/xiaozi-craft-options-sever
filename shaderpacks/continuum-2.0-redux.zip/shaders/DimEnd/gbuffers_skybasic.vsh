#version 430 compatibility
#define vert 

#include "../Passes/GBuffersDiscard.vert"

