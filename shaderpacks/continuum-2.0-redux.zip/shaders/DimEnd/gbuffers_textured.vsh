#version 430 compatibility

#define vert
#define gbuffers_textured
#define DIM_END

#include "../Passes/GBuffersMain.vert"
