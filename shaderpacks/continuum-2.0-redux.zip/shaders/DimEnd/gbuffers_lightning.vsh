#version 430 compatibility

#define vert
#define gbuffers_lightning
#define DIM_END

#include "../Passes/GBuffersMain.vert"
