#version 430 compatibility

#define frag
#define gbuffers_terrain
#define DIM_END

#include "../Passes/GBuffersMain.frag"
