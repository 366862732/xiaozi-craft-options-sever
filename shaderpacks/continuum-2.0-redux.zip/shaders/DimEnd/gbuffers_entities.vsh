#version 430 compatibility

#define vert
#define gbuffers_entities
#define DIM_END

#include "../Passes/GBuffersMain.vert"
