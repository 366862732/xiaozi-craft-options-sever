#version 430 compatibility

#define frag
#define gbuffers_weather
#define DIM_END

#include "../Passes/GBuffersWeather.frag"