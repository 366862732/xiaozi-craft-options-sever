void main() { 
    discard;
}