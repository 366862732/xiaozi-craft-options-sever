#version 430
#define comp
#define DIM_NETHER

#include "../Passes/C4A_GenBokehImg.comp"