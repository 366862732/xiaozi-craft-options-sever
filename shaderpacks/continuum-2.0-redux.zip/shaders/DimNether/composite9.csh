#version 430 compatibility
#define comp
#define DIM_NETHER

#include "../Passes/C9_CopyFroxels.comp"