#version 430 compatibility

#define vsh
#define DIM_NETHER

#include "../Passes/Shadow.vert"
