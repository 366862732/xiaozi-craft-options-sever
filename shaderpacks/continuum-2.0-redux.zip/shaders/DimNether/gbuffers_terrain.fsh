#version 430 compatibility

#define frag
#define gbuffers_terrain
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
