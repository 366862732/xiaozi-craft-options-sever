#version 430 compatibility

#define vert
#define gbuffers_hand
#define DIM_NETHER

#include "../Passes/GBuffersMain.vert"
