#version 430 compatibility

#define frag
#define gbuffers_textured
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
