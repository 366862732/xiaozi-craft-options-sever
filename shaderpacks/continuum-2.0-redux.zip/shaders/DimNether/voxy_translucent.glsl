#define DIM_NETHER
#include "../Passes/GBuffersLODTranslucent.glsl"