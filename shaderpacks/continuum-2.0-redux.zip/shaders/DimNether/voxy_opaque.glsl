#define DIM_NETHER
#include "../Passes/GBuffersLOD.glsl"