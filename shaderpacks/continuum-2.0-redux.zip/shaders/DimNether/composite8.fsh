#version 430 compatibility
#define comp
#define DIM_NETHER

#include "../Passes/C8_TAA.frag"
