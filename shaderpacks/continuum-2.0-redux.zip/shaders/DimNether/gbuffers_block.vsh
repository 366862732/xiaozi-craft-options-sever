#version 430 compatibility

#define vert
#define gbuffers_block
#define DIM_NETHER

#include "../Passes/GBuffersMain.vert"
