#version 430 compatibility

#define vert
#define gbuffers_weather
#define DIM_NETHER

#include "../Passes/GBuffersWeather.vert"