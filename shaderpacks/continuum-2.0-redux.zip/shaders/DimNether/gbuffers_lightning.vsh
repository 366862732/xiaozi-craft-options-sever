#version 430 compatibility

#define vert
#define gbuffers_lightning
#define DIM_NETHER

#include "../Passes/GBuffersMain.vert"
