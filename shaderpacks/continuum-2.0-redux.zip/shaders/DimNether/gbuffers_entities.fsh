#version 430 compatibility

#define frag
#define gbuffers_entities
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
