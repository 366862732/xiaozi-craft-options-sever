#version 430 compatibility

#define vert
#define gbuffers_entities
#define DIM_NETHER

#include "../Passes/GBuffersMain.vert"
