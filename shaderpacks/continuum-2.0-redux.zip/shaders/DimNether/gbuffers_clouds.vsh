#version 430 compatibility
#define vert 
#define DIM_NETHER

#include "../Passes/GBuffersDiscard.vert"
