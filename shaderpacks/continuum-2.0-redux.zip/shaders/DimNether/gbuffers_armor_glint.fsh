#version 430 compatibility

#define frag
#define gbuffers_armor_glint
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
