#version 430
#define comp
#define DIM_NETHER

#include "../Passes/C1_IntegrateFroxels.comp"