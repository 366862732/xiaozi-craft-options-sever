#version 430 compatibility

#define frag
#define gbuffers_block
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
