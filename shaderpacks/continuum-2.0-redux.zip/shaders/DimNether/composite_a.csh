#version 430
#define comp
#define DIM_NETHER

#include "../Passes/C0A_GenerateFroxels.comp"