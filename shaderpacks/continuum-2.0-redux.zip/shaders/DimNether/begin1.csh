#version 430
#define comp
#define DIM_NETHER

#include "../Passes/B1_GenWaveFieldX.comp"