
#version 430 compatibility
#define frag
#define DIM_NETHER

#include "../Passes/C7_PostProcess1.frag"