#version 430 compatibility

#define frag
#define gbuffers_lightning
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
