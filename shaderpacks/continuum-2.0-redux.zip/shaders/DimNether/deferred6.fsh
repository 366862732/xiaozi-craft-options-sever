#version 430 compatibility
#define frag
#define DIM_NETHER
 
#include "../Passes/D6_FilterGIY.frag"