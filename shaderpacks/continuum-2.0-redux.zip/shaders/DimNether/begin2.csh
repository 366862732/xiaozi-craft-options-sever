#version 430
#define comp
#define DIM_NETHER

#include "../Passes/B2_GenWaveFieldY.comp"