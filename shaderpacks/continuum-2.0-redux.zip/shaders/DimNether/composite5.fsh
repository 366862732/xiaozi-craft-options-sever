#version 430 compatibility
#define frag
#define DIM_NETHER

#include "../Passes/C5_CompositeScene.frag"
