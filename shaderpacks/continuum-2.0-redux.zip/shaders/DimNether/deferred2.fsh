#version 430 compatibility
#define frag
#define DIM_NETHER

#include "../Passes/D2_RenderEquirectSkyImg.frag"