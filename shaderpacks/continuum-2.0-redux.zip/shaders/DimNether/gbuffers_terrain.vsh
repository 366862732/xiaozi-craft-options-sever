#version 430 compatibility

#define vert
#define gbuffers_terrain
#define DIM_NETHER

#include "../Passes/GBuffersMain.vert"
