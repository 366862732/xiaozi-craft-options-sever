#version 430 compatibility

#define vert
#define gbuffers_textured
#define DIM_NETHER

#include "../Passes/GBuffersMain.vert"
