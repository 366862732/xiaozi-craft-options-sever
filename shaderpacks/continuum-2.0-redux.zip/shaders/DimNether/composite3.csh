#version 430
#define comp
#define DIM_NETHER

#include "../Passes/C3_UpscaleClouds.comp"