#version 430 compatibility

#define frag
#define gbuffers_water
#define DIM_NETHER

#include "../Passes/GBuffersMainTranslucent.frag"
