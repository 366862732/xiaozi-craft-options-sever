#version 430 compatibility

#define frag
#define gbuffers_hand
#define DIM_NETHER

#include "../Passes/GBuffersMain.frag"
