#version 430 compatibility
#define comp
#define DIM_NETHER

#include "../Passes/D0A_PropagateLight.comp"