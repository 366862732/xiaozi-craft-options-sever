#version 430 compatibility
#define comp
#define DIM_NETHER

#include "../Passes/B0_InitSSBOs.comp"