#version 430 compatibility

#define frag
#define gbuffers_weather
#define DIM_NETHER

#include "../Passes/GBuffersWeather.frag"