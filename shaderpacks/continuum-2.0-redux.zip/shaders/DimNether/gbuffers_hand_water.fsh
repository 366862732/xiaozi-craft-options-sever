#version 430 compatibility

#define frag
#define gbuffers_hand_water
#define DIM_NETHER

#include "../Passes/GBuffersMainTranslucent.frag"