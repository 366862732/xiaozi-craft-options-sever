#version 430 compatibility
#define frag
#define DIM_OVERWORLD

#include "../Passes/C6_PostProcess0.frag"
