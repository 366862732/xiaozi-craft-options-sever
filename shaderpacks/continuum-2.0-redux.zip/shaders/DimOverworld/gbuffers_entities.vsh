#version 430 compatibility

#define vert
#define gbuffers_entities
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.vert"
