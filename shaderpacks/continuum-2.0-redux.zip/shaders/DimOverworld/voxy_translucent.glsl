#define DIM_OVERWORLD
#include "../Passes/GBuffersLODTranslucent.glsl"