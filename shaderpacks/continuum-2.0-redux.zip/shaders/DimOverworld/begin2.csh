#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/B2_GenWaveFieldY.comp"