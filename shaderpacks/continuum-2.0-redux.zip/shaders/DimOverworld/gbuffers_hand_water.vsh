#version 430 compatibility

#define vert
#define gbuffers_hand_water
#define DIM_OVERWORLD

#include "../Passes/GBuffersMainTranslucent.vert"