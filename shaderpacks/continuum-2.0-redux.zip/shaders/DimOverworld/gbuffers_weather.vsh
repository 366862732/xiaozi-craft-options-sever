#version 430 compatibility

#define vert
#define gbuffers_weather
#define DIM_OVERWORLD

#include "../Passes/GBuffersWeather.vert"