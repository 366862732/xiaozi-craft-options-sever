#version 430 compatibility
#define comp
#define DIM_OVERWORLD

#include "../Passes/C8_TAA.frag"
