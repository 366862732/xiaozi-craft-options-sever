#version 430 compatibility
#define comp
#define DIM_OVERWORLD

#include "../Passes/D3_GenSH.comp"