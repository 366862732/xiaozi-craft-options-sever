#version 430 compatibility
#define frag
#define DIM_OVERWORLD
 
#include "../Passes/D4_RenderGI.frag"