#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/C1_IntegrateFroxels.comp"