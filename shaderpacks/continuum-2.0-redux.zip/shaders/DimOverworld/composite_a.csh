#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/C0A_GenerateFroxels.comp"