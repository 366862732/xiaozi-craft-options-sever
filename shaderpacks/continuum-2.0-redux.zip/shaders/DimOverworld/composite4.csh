#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/C4_CopyClouds.comp"