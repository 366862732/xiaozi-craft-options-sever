#version 430 compatibility

#define vert
#define gbuffers_terrain
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.vert"
