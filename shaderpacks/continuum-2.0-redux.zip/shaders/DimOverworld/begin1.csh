#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/B1_GenWaveFieldX.comp"