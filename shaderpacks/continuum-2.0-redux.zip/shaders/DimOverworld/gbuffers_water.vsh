#version 430 compatibility

#define vert
#define gbuffers_water
#define DIM_OVERWORLD

#include "../Passes/GBuffersMainTranslucent.vert"
