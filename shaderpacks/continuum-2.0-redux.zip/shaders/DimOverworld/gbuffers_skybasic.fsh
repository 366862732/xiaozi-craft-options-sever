#version 430 compatibility
#define frag
#define DIM_OVERWORLD

#include "../Passes/GBuffersDiscard.frag"
