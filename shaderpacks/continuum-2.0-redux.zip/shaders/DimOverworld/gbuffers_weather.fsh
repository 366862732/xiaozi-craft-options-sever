#version 430 compatibility

#define frag
#define gbuffers_weather
#define DIM_OVERWORLD

#include "../Passes/GBuffersWeather.frag"