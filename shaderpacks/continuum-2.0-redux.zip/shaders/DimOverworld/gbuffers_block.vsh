#version 430 compatibility

#define vert
#define gbuffers_block
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.vert"
