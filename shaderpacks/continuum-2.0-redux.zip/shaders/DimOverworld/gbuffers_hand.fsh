#version 430 compatibility

#define frag
#define gbuffers_hand
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
