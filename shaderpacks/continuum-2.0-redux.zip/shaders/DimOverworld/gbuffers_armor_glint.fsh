#version 430 compatibility

#define frag
#define gbuffers_armor_glint
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
