#version 430 compatibility
#define comp
#define DIM_OVERWORLD

#include "../Passes/D0_ConstructDepth.comp"