
#version 430 compatibility
#define frag
#define DIM_OVERWORLD

#include "../Passes/C7_PostProcess1.frag"