#version 430 compatibility

#define vert
#define gbuffers_lightning
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.vert"
