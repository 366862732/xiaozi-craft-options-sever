#version 430 compatibility
#define comp
#define DIM_OVERWORLD

#include "../Passes/B0_InitSSBOs.comp"