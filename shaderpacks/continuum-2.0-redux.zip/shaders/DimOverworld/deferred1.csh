#version 430 compatibility
#define comp
#define DIM_OVERWORLD

#include "../Passes/D1_CopyLPV.comp"