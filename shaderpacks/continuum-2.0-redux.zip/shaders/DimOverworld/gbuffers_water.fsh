#version 430 compatibility

#define frag
#define gbuffers_water
#define DIM_OVERWORLD

#include "../Passes/GBuffersMainTranslucent.frag"
