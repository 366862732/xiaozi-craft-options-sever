#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/C4A_GenBokehImg.comp"