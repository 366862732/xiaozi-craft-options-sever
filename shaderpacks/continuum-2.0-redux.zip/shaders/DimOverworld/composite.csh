#version 430
#define comp
#define DIM_OVERWORLD

#include "../Passes/C0_ConstructDepth.comp"