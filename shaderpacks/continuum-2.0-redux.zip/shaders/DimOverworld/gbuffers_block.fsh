#version 430 compatibility

#define frag
#define gbuffers_block
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
