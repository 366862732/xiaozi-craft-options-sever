#version 430 compatibility

#define frag
#define gbuffers_textured
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
