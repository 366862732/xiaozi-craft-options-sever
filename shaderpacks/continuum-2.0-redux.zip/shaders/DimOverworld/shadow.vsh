#version 430 compatibility

#define vsh
#define DIM_OVERWORLD

#include "../Passes/Shadow.vert"
