#version 430 compatibility

#define frag
#define gbuffers_entities
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
