#version 430 compatibility

#define vert
#define gbuffers_hand
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.vert"
