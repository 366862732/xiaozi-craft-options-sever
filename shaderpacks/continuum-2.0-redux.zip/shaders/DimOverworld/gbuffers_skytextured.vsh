#version 430 compatibility
#define vert
#define DIM_OVERWORLD

#include "../Passes/GBuffersDiscard.vert"
