#version 430 compatibility
#define frag
#define DIM_OVERWORLD

#include "../Passes/C5_CompositeScene.frag"
