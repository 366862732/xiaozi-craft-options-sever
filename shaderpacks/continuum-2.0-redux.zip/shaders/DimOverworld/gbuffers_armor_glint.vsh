#version 430 compatibility

#define vert
#define gbuffers_armor_glint
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.vert"
