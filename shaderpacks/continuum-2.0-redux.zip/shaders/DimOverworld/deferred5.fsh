#version 430 compatibility
#define frag
#define DIM_OVERWORLD
 
#include "../Passes/D5_FilterGIX.frag"