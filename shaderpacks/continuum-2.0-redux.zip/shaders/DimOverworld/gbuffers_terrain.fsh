#version 430 compatibility

#define frag
#define gbuffers_terrain
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
