#version 430 compatibility

#define frag
#define gbuffers_lightning
#define DIM_OVERWORLD

#include "../Passes/GBuffersMain.frag"
